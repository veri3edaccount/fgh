import { Router } from 'express';
import { Guild } from '../../database/schemas/Guild.js';
import { verifyToken } from './auth.js';

const router = Router();

// Get user's guilds
router.get('/', verifyToken, async (req: any, res) => {
  try {
    const userGuilds = req.user.guilds;
    const guildIds = userGuilds.map((g: any) => g.id);
    
    // Get guild settings from database
    const guildSettings = await Guild.find({ _id: { $in: guildIds } });
    
    // Merge Discord guild info with database settings
    const guilds = userGuilds.map((discordGuild: any) => {
      const settings = guildSettings.find(g => g._id === discordGuild.id);
      return {
        ...discordGuild,
        settings: settings || null
      };
    });
    
    res.json(guilds);
  } catch (error) {
    console.error('Error fetching guilds:', error);
    res.status(500).json({ error: 'Failed to fetch guilds' });
  }
});

// Get specific guild settings
router.get('/:guildId', verifyToken, async (req: any, res) => {
  try {
    const { guildId } = req.params;
    
    // Check if user has access to this guild
    const hasAccess = req.user.guilds.some((g: any) => g.id === guildId);
    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    let guild = await Guild.findById(guildId);
    if (!guild) {
      // Create default guild settings
      guild = new Guild({
        _id: guildId,
        name: req.user.guilds.find((g: any) => g.id === guildId)?.name || 'Unknown Guild'
      });
      await guild.save();
    }
    
    res.json(guild);
  } catch (error) {
    console.error('Error fetching guild:', error);
    res.status(500).json({ error: 'Failed to fetch guild' });
  }
});

// Update guild settings
router.put('/:guildId', verifyToken, async (req: any, res) => {
  try {
    const { guildId } = req.params;
    const updates = req.body;
    
    // Check if user has access to this guild
    const hasAccess = req.user.guilds.some((g: any) => g.id === guildId);
    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    const guild = await Guild.findByIdAndUpdate(
      guildId,
      { $set: updates },
      { new: true, upsert: true }
    );
    
    res.json(guild);
  } catch (error) {
    console.error('Error updating guild:', error);
    res.status(500).json({ error: 'Failed to update guild' });
  }
});

// Reset guild settings
router.post('/:guildId/reset', verifyToken, async (req: any, res) => {
  try {
    const { guildId } = req.params;
    
    // Check if user has access to this guild
    const hasAccess = req.user.guilds.some((g: any) => g.id === guildId);
    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    await Guild.findByIdAndDelete(guildId);
    
    // Create new default settings
    const guild = new Guild({
      _id: guildId,
      name: req.user.guilds.find((g: any) => g.id === guildId)?.name || 'Unknown Guild'
    });
    await guild.save();
    
    res.json(guild);
  } catch (error) {
    console.error('Error resetting guild:', error);
    res.status(500).json({ error: 'Failed to reset guild' });
  }
});

export { router as guildRoutes };