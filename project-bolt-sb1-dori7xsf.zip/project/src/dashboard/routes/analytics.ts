import { Router } from 'express';
import { User } from '../../database/schemas/User.js';
import { redisClient } from '../../database/connection.js';
import { verifyToken } from './auth.js';

const router = Router();

// Get guild analytics
router.get('/guild/:guildId', verifyToken, async (req: any, res) => {
  try {
    const { guildId } = req.params;
    const { days = 7 } = req.query;
    
    // Check if user has access to this guild
    const hasAccess = req.user.guilds.some((g: any) => g.id === guildId);
    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    const stats = {
      messages: 0,
      commands: 0,
      activeUsers: 0,
      dailyStats: []
    };

    if (redisClient) {
      // Get daily stats for the specified period
      for (let i = 0; i < parseInt(days); i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateString = date.toDateString();

        const messages = await redisClient.get(`messages:guild:${guildId}:${dateString}`);
        const commands = await redisClient.get(`commands:guild:${guildId}:${dateString}`);

        const dayStats = {
          date: dateString,
          messages: parseInt(messages || '0'),
          commands: parseInt(commands || '0')
        };

        stats.dailyStats.unshift(dayStats);
        stats.messages += dayStats.messages;
        stats.commands += dayStats.commands;
      }
    }

    res.json(stats);
  } catch (error) {
    console.error('Error fetching guild analytics:', error);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

// Get user leaderboard
router.get('/leaderboard/:guildId', verifyToken, async (req: any, res) => {
  try {
    const { guildId } = req.params;
    const { type = 'experience', limit = 10 } = req.query;
    
    // Check if user has access to this guild
    const hasAccess = req.user.guilds.some((g: any) => g.id === guildId);
    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    let sortField = 'experience.total';
    
    switch (type) {
      case 'messages':
        sortField = 'experience.messageCount';
        break;
      case 'commands':
        sortField = 'experience.commandsUsed';
        break;
      case 'voice':
        sortField = 'experience.voiceTime';
        break;
      case 'economy':
        // Use aggregation for total wealth
        const economyLeaderboard = await User.aggregate([
          {
            $addFields: {
              totalWealth: { $add: ['$economy.balance', '$economy.bank'] }
            }
          },
          { $sort: { totalWealth: -1 } },
          { $limit: parseInt(limit as string) },
          {
            $project: {
              username: 1,
              discriminator: 1,
              avatar: 1,
              totalWealth: 1,
              'economy.balance': 1,
              'economy.bank': 1
            }
          }
        ]);
        
        return res.json(economyLeaderboard);
    }
    
    const leaderboard = await User.find({})
      .sort({ [sortField]: -1 })
      .limit(parseInt(limit as string))
      .select('username discriminator avatar experience statistics economy');
    
    res.json(leaderboard);
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    res.status(500).json({ error: 'Failed to fetch leaderboard' });
  }
});

// Get command usage statistics
router.get('/commands/:guildId', verifyToken, async (req: any, res) => {
  try {
    const { guildId } = req.params;
    const { days = 7 } = req.query;
    
    // Check if user has access to this guild
    const hasAccess = req.user.guilds.some((g: any) => g.id === guildId);
    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    const commandStats: any = {};

    if (redisClient) {
      // Get command usage for the specified period
      for (let i = 0; i < parseInt(days); i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateString = date.toDateString();

        // This is a simplified version - you'd need to track individual commands
        const keys = await redisClient.keys(`commands:*:${dateString}`);
        
        for (const key of keys) {
          const parts = key.split(':');
          if (parts.length >= 3) {
            const commandName = parts[1];
            const count = await redisClient.get(key);
            
            if (!commandStats[commandName]) {
              commandStats[commandName] = 0;
            }
            commandStats[commandName] += parseInt(count || '0');
          }
        }
      }
    }

    // Convert to array and sort
    const sortedCommands = Object.entries(commandStats)
      .map(([name, count]) => ({ name, count }))
      .sort((a: any, b: any) => b.count - a.count)
      .slice(0, 20);

    res.json(sortedCommands);
  } catch (error) {
    console.error('Error fetching command stats:', error);
    res.status(500).json({ error: 'Failed to fetch command statistics' });
  }
});

export { router as analyticsRoutes };