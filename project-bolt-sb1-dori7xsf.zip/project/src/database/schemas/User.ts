import { Schema, model } from 'mongoose';

export interface IUser {
  _id: string;
  username: string;
  discriminator: string;
  avatar?: string;
  
  // Economy
  economy: {
    balance: number;
    bank: number;
    dailyStreak: number;
    lastDaily: Date;
    lastWork: Date;
    totalEarned: number;
    totalSpent: number;
    inventory: Array<{
      item: string;
      quantity: number;
      purchaseDate: Date;
    }>;
  };

  // Experience & Levels
  experience: {
    total: number;
    level: number;
    messageCount: number;
    voiceTime: number;
    commandsUsed: number;
  };

  // Moderation History
  moderation: {
    warnings: Array<{
      reason: string;
      moderator: string;
      date: Date;
      guildId: string;
    }>;
    mutes: Array<{
      reason: string;
      moderator: string;
      duration: number;
      date: Date;
      guildId: string;
    }>;
    kicks: Array<{
      reason: string;
      moderator: string;
      date: Date;
      guildId: string;
    }>;
    bans: Array<{
      reason: string;
      moderator: string;
      date: Date;
      guildId: string;
      unbanned?: boolean;
      unbannedBy?: string;
      unbannedDate?: Date;
    }>;
  };

  // AI Profile
  aiProfile: {
    personality: string;
    preferences: Map<string, any>;
    conversationHistory: Array<{
      message: string;
      response: string;
      timestamp: Date;
    }>;
  };

  // Statistics
  statistics: {
    gamesPlayed: number;
    gamesWon: number;
    totalWinnings: number;
    commandsUsed: number;
    messagesDeleted: number;
    reactionsAdded: number;
  };

  // Settings
  settings: {
    notifications: boolean;
    dmCommands: boolean;
    aiResponses: boolean;
    language: string;
    timezone: string;
  };

  // Global Data (across all servers)
  global: {
    reputation: number;
    achievements: string[];
    badges: string[];
    globalBans: Array<{
      reason: string;
      bannedBy: string;
      date: Date;
      network: string;
    }>;
  };

  createdAt: Date;
  updatedAt: Date;
}

const userSchema = new Schema<IUser>({
  _id: { type: String, required: true },
  username: { type: String, required: true },
  discriminator: { type: String, required: true },
  avatar: String,

  economy: {
    balance: { type: Number, default: 1000 },
    bank: { type: Number, default: 0 },
    dailyStreak: { type: Number, default: 0 },
    lastDaily: Date,
    lastWork: Date,
    totalEarned: { type: Number, default: 0 },
    totalSpent: { type: Number, default: 0 },
    inventory: [{
      item: String,
      quantity: Number,
      purchaseDate: Date
    }]
  },

  experience: {
    total: { type: Number, default: 0 },
    level: { type: Number, default: 1 },
    messageCount: { type: Number, default: 0 },
    voiceTime: { type: Number, default: 0 },
    commandsUsed: { type: Number, default: 0 }
  },

  moderation: {
    warnings: [{
      reason: String,
      moderator: String,
      date: Date,
      guildId: String
    }],
    mutes: [{
      reason: String,
      moderator: String,
      duration: Number,
      date: Date,
      guildId: String
    }],
    kicks: [{
      reason: String,
      moderator: String,
      date: Date,
      guildId: String
    }],
    bans: [{
      reason: String,
      moderator: String,
      date: Date,
      guildId: String,
      unbanned: Boolean,
      unbannedBy: String,
      unbannedDate: Date
    }]
  },

  aiProfile: {
    personality: { type: String, default: 'friendly' },
    preferences: { type: Map, of: Schema.Types.Mixed },
    conversationHistory: [{
      message: String,
      response: String,
      timestamp: Date
    }]
  },

  statistics: {
    gamesPlayed: { type: Number, default: 0 },
    gamesWon: { type: Number, default: 0 },
    totalWinnings: { type: Number, default: 0 },
    commandsUsed: { type: Number, default: 0 },
    messagesDeleted: { type: Number, default: 0 },
    reactionsAdded: { type: Number, default: 0 }
  },

  settings: {
    notifications: { type: Boolean, default: true },
    dmCommands: { type: Boolean, default: true },
    aiResponses: { type: Boolean, default: true },
    language: { type: String, default: 'en' },
    timezone: { type: String, default: 'UTC' }
  },

  global: {
    reputation: { type: Number, default: 0 },
    achievements: [String],
    badges: [String],
    globalBans: [{
      reason: String,
      bannedBy: String,
      date: Date,
      network: String
    }]
  }
}, {
  timestamps: true
});

export const User = model<IUser>('User', userSchema);