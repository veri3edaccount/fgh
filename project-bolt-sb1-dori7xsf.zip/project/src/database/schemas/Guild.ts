import { Schema, model } from 'mongoose';

export interface IGuild {
  _id: string;
  name: string;
  prefix: string;
  language: string;
  
  // Moderation Settings
  moderation: {
    enabled: boolean;
    logChannel?: string;
    mutedRole?: string;
    automod: {
      enabled: boolean;
      filterProfanity: boolean;
      filterSpam: boolean;
      filterInvites: boolean;
      filterLinks: boolean;
      aiModeration: boolean;
      maxWarnings: number;
      muteThreshold: number;
      banThreshold: number;
    };
    antiRaid: {
      enabled: boolean;
      joinThreshold: number;
      timeWindow: number;
      action: 'kick' | 'ban' | 'lockdown';
    };
  };

  // Economy Settings
  economy: {
    enabled: boolean;
    currency: string;
    dailyAmount: number;
    workAmount: number;
    startingBalance: number;
  };

  // Ticket Settings
  tickets: {
    enabled: boolean;
    category?: string;
    supportRole?: string;
    departments: Array<{
      name: string;
      emoji: string;
      role?: string;
    }>;
  };

  // Reaction Roles
  reactionRoles: Array<{
    messageId: string;
    channelId: string;
    roles: Array<{
      emoji: string;
      roleId: string;
    }>;
  }>;

  // Custom Commands
  customCommands: Array<{
    trigger: string;
    response: string;
    permissions: string[];
    cooldown: number;
  }>;

  // Analytics
  analytics: {
    enabled: boolean;
    trackMessages: boolean;
    trackVoice: boolean;
    trackCommands: boolean;
  };

  // Integrations
  integrations: {
    twitch: {
      enabled: boolean;
      channels: Array<{
        username: string;
        discordChannel: string;
        message: string;
      }>;
    };
    youtube: {
      enabled: boolean;
      channels: Array<{
        channelId: string;
        discordChannel: string;
        message: string;
      }>;
    };
  };

  createdAt: Date;
  updatedAt: Date;
}

const guildSchema = new Schema<IGuild>({
  _id: { type: String, required: true },
  name: { type: String, required: true },
  prefix: { type: String, default: '!' },
  language: { type: String, default: 'en' },
  
  moderation: {
    enabled: { type: Boolean, default: true },
    logChannel: String,
    mutedRole: String,
    automod: {
      enabled: { type: Boolean, default: true },
      filterProfanity: { type: Boolean, default: true },
      filterSpam: { type: Boolean, default: true },
      filterInvites: { type: Boolean, default: false },
      filterLinks: { type: Boolean, default: false },
      aiModeration: { type: Boolean, default: false },
      maxWarnings: { type: Number, default: 3 },
      muteThreshold: { type: Number, default: 5 },
      banThreshold: { type: Number, default: 10 }
    },
    antiRaid: {
      enabled: { type: Boolean, default: true },
      joinThreshold: { type: Number, default: 10 },
      timeWindow: { type: Number, default: 60 },
      action: { type: String, enum: ['kick', 'ban', 'lockdown'], default: 'kick' }
    }
  },

  economy: {
    enabled: { type: Boolean, default: true },
    currency: { type: String, default: '💰' },
    dailyAmount: { type: Number, default: 1000 },
    workAmount: { type: Number, default: 500 },
    startingBalance: { type: Number, default: 1000 }
  },

  tickets: {
    enabled: { type: Boolean, default: false },
    category: String,
    supportRole: String,
    departments: [{
      name: String,
      emoji: String,
      role: String
    }]
  },

  reactionRoles: [{
    messageId: String,
    channelId: String,
    roles: [{
      emoji: String,
      roleId: String
    }]
  }],

  customCommands: [{
    trigger: String,
    response: String,
    permissions: [String],
    cooldown: { type: Number, default: 0 }
  }],

  analytics: {
    enabled: { type: Boolean, default: true },
    trackMessages: { type: Boolean, default: true },
    trackVoice: { type: Boolean, default: true },
    trackCommands: { type: Boolean, default: true }
  },

  integrations: {
    twitch: {
      enabled: { type: Boolean, default: false },
      channels: [{
        username: String,
        discordChannel: String,
        message: String
      }]
    },
    youtube: {
      enabled: { type: Boolean, default: false },
      channels: [{
        channelId: String,
        discordChannel: String,
        message: String
      }]
    }
  }
}, {
  timestamps: true
});

export const Guild = model<IGuild>('Guild', guildSchema);