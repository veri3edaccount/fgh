import mongoose from 'mongoose';
import { createClient } from 'redis';
import { logger } from '../utils/logger.js';

export let redisClient: any;

export async function connectDatabase() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/ultimate-discord-bot');
    logger.info('Connected to MongoDB');

    // Connect to Redis
    redisClient = createClient({
      url: process.env.REDIS_URL || 'redis://localhost:6379'
    });
    
    redisClient.on('error', (err: any) => logger.error('Redis Client Error', err));
    await redisClient.connect();
    logger.info('Connected to Redis');

  } catch (error) {
    logger.error('Database connection failed:', error);
    throw error;
  }
}

export { mongoose };