import OpenAI from 'openai';
import { logger } from '../../utils/logger.js';
import type { UltimateBot } from '../../index.js';

export class AutoModManager {
  private bot: UltimateBot;
  private openai?: OpenAI;

  constructor(bot: UltimateBot) {
    this.bot = bot;
    
    if (process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
    }
  }

  async initialize() {
    logger.info('AutoMod Manager initialized');
  }

  async analyzeMessage(content: string, context: any): Promise<{
    shouldFlag: boolean;
    confidence: number;
    reasons: string[];
    suggestedAction: 'none' | 'warn' | 'mute' | 'kick' | 'ban';
  }> {
    try {
      if (!this.openai) {
        return this.fallbackAnalysis(content);
      }

      const response = await this.openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: `You are a Discord moderation AI. Analyze messages for violations including:
            - Hate speech, harassment, discrimination
            - Spam, excessive caps, repetitive content
            - Inappropriate content for the community
            - Threats or encouraging harmful behavior
            
            Respond with JSON format:
            {
              "shouldFlag": boolean,
              "confidence": 0-100,
              "reasons": ["reason1", "reason2"],
              "suggestedAction": "none|warn|mute|kick|ban"
            }`
          },
          {
            role: 'user',
            content: `Analyze this message: "${content}"`
          }
        ],
        max_tokens: 200,
        temperature: 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      return {
        shouldFlag: result.shouldFlag || false,
        confidence: result.confidence || 0,
        reasons: result.reasons || [],
        suggestedAction: result.suggestedAction || 'none'
      };

    } catch (error) {
      logger.error('Error in AI message analysis:', error);
      return this.fallbackAnalysis(content);
    }
  }

  private fallbackAnalysis(content: string): {
    shouldFlag: boolean;
    confidence: number;
    reasons: string[];
    suggestedAction: 'none' | 'warn' | 'mute' | 'kick' | 'ban';
  } {
    const reasons = [];
    let confidence = 0;

    // Basic profanity check
    const profanityWords = ['fuck', 'shit', 'damn', 'hell', 'bitch', 'asshole'];
    const containsProfanity = profanityWords.some(word => 
      content.toLowerCase().includes(word)
    );

    if (containsProfanity) {
      reasons.push('Profanity detected');
      confidence += 30;
    }

    // Excessive caps check
    const capsRatio = (content.match(/[A-Z]/g) || []).length / content.length;
    if (capsRatio > 0.7 && content.length > 10) {
      reasons.push('Excessive caps');
      confidence += 20;
    }

    // Spam patterns
    const repeatedChars = /(.)\1{4,}/.test(content);
    if (repeatedChars) {
      reasons.push('Spam patterns');
      confidence += 25;
    }

    return {
      shouldFlag: confidence > 50,
      confidence,
      reasons,
      suggestedAction: confidence > 80 ? 'mute' : confidence > 50 ? 'warn' : 'none'
    };
  }

  async generateAutoResponse(message: string, context: any): Promise<string | null> {
    try {
      if (!this.openai) return null;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful Discord bot assistant. Provide brief, friendly responses to user messages. Keep responses under 100 words.'
          },
          {
            role: 'user',
            content: message
          }
        ],
        max_tokens: 150,
        temperature: 0.7
      });

      return response.choices[0].message.content || null;

    } catch (error) {
      logger.error('Error generating auto response:', error);
      return null;
    }
  }
}