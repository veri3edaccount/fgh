import { CronJob } from 'cron';
import { User } from '../../database/schemas/User.js';
import { logger } from '../../utils/logger.js';
import type { UltimateBot } from '../../index.js';

export class EconomyManager {
  private bot: UltimateBot;
  private interestJob?: CronJob;

  constructor(bot: UltimateBot) {
    this.bot = bot;
  }

  async initialize() {
    // Start daily interest calculation
    this.interestJob = new CronJob('0 0 * * *', this.calculateDailyInterest.bind(this), null, true);
    logger.info('Economy Manager initialized');
  }

  private async calculateDailyInterest() {
    try {
      const users = await User.find({ 'economy.bank': { $gt: 0 } });
      
      for (const user of users) {
        const interestRate = 0.01; // 1% daily interest
        const interest = Math.floor(user.economy.bank * interestRate);
        
        if (interest > 0) {
          user.economy.bank += interest;
          user.economy.totalEarned += interest;
          await user.save();
        }
      }

      logger.info(`Calculated daily interest for ${users.length} users`);
    } catch (error) {
      logger.error('Error calculating daily interest:', error);
    }
  }

  async transferMoney(fromUserId: string, toUserId: string, amount: number): Promise<boolean> {
    try {
      const fromUser = await User.findById(fromUserId);
      const toUser = await User.findById(toUserId);

      if (!fromUser || !toUser) return false;
      if (fromUser.economy.balance < amount) return false;

      fromUser.economy.balance -= amount;
      fromUser.economy.totalSpent += amount;
      toUser.economy.balance += amount;
      toUser.economy.totalEarned += amount;

      await fromUser.save();
      await toUser.save();

      return true;
    } catch (error) {
      logger.error('Error transferring money:', error);
      return false;
    }
  }

  async getLeaderboard(type: 'balance' | 'bank' | 'total' = 'total', limit: number = 10) {
    try {
      let sortField: string;
      
      switch (type) {
        case 'balance':
          sortField = 'economy.balance';
          break;
        case 'bank':
          sortField = 'economy.bank';
          break;
        case 'total':
        default:
          // We'll need to use aggregation for total wealth
          return await User.aggregate([
            {
              $addFields: {
                totalWealth: { $add: ['$economy.balance', '$economy.bank'] }
              }
            },
            { $sort: { totalWealth: -1 } },
            { $limit: limit }
          ]);
      }

      return await User.find({}).sort({ [sortField]: -1 }).limit(limit);
    } catch (error) {
      logger.error('Error getting leaderboard:', error);
      return [];
    }
  }

  async addItem(userId: string, item: string, quantity: number = 1): Promise<boolean> {
    try {
      const user = await User.findById(userId);
      if (!user) return false;

      const existingItem = user.economy.inventory.find(i => i.item === item);
      
      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        user.economy.inventory.push({
          item,
          quantity,
          purchaseDate: new Date()
        });
      }

      await user.save();
      return true;
    } catch (error) {
      logger.error('Error adding item:', error);
      return false;
    }
  }

  async removeItem(userId: string, item: string, quantity: number = 1): Promise<boolean> {
    try {
      const user = await User.findById(userId);
      if (!user) return false;

      const existingItem = user.economy.inventory.find(i => i.item === item);
      if (!existingItem || existingItem.quantity < quantity) return false;

      existingItem.quantity -= quantity;
      
      if (existingItem.quantity <= 0) {
        user.economy.inventory = user.economy.inventory.filter(i => i.item !== item);
      }

      await user.save();
      return true;
    } catch (error) {
      logger.error('Error removing item:', error);
      return false;
    }
  }
}