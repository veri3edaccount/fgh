import OpenAI from 'openai';
import { User } from '../../database/schemas/User.js';
import { logger } from '../../utils/logger.js';
import type { UltimateBot } from '../../index.js';

export class AIManager {
  private bot: UltimateBot;
  private openai?: OpenAI;

  constructor(bot: UltimateBot) {
    this.bot = bot;
    
    if (process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
    }
  }

  async initialize() {
    logger.info('AI Manager initialized');
  }

  async generateResponse(userId: string, message: string, context?: any): Promise<string | null> {
    try {
      if (!this.openai) {
        return this.generateFallbackResponse(message);
      }

      // Get user's AI profile for personalization
      const userData = await User.findById(userId);
      const personality = userData?.aiProfile.personality || 'friendly';
      const preferences = userData?.aiProfile.preferences || new Map();

      const systemPrompt = this.buildSystemPrompt(personality, preferences, context);

      const response = await this.openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: message }
        ],
        max_tokens: 200,
        temperature: 0.8
      });

      const aiResponse = response.choices[0].message.content;

      // Save conversation to user's history
      if (userData && aiResponse) {
        userData.aiProfile.conversationHistory.push({
          message,
          response: aiResponse,
          timestamp: new Date()
        });

        // Keep only last 50 conversations
        if (userData.aiProfile.conversationHistory.length > 50) {
          userData.aiProfile.conversationHistory = userData.aiProfile.conversationHistory.slice(-50);
        }

        await userData.save();
      }

      return aiResponse;

    } catch (error) {
      logger.error('Error generating AI response:', error);
      return this.generateFallbackResponse(message);
    }
  }

  private buildSystemPrompt(personality: string, preferences: Map<string, any>, context?: any): string {
    let prompt = `You are a Discord bot assistant with a ${personality} personality. `;

    switch (personality) {
      case 'professional':
        prompt += 'Be formal, concise, and helpful. Focus on providing accurate information.';
        break;
      case 'casual':
        prompt += 'Be relaxed, use casual language, and be approachable. Use emojis occasionally.';
        break;
      case 'humorous':
        prompt += 'Be witty and entertaining. Make jokes when appropriate, but stay helpful.';
        break;
      case 'supportive':
        prompt += 'Be encouraging, empathetic, and understanding. Offer emotional support.';
        break;
      default:
        prompt += 'Be friendly, helpful, and engaging. Maintain a positive tone.';
    }

    prompt += ' Keep responses under 200 words. If asked about moderation or technical issues, provide helpful guidance.';

    if (context?.isModeration) {
      prompt += ' You are in a moderation context. Be professional and provide clear guidance.';
    }

    return prompt;
  }

  private generateFallbackResponse(message: string): string {
    const responses = [
      "I'm here to help! What would you like to know?",
      "That's interesting! Tell me more about it.",
      "I appreciate you sharing that with me!",
      "Thanks for the message! How can I assist you today?",
      "I'm listening! What's on your mind?",
      "Great question! Let me think about that.",
      "I'm glad you asked! Here's what I think...",
      "That's a good point! Thanks for bringing it up."
    ];

    // Simple keyword-based responses
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
      return "Hello there! How can I help you today? 👋";
    }
    
    if (lowerMessage.includes('thank')) {
      return "You're very welcome! Happy to help! 😊";
    }
    
    if (lowerMessage.includes('help')) {
      return "I'd be happy to help! What do you need assistance with?";
    }
    
    if (lowerMessage.includes('how are you')) {
      return "I'm doing great, thanks for asking! How are you doing?";
    }

    return responses[Math.floor(Math.random() * responses.length)];
  }

  async updateUserPersonality(userId: string, personality: string, preferences?: any): Promise<boolean> {
    try {
      await User.findByIdAndUpdate(userId, {
        $set: {
          'aiProfile.personality': personality,
          'aiProfile.preferences': preferences || {}
        }
      }, { upsert: true });

      return true;
    } catch (error) {
      logger.error('Error updating user personality:', error);
      return false;
    }
  }

  async generateImagePrompt(description: string): Promise<string | null> {
    try {
      if (!this.openai) return null;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'You are an expert at creating detailed, artistic image prompts for AI image generation. Transform user descriptions into vivid, detailed prompts that will create amazing images.'
          },
          {
            role: 'user',
            content: `Create a detailed image prompt for: ${description}`
          }
        ],
        max_tokens: 150,
        temperature: 0.8
      });

      return response.choices[0].message.content;

    } catch (error) {
      logger.error('Error generating image prompt:', error);
      return null;
    }
  }

  async summarizeConversation(messages: string[]): Promise<string | null> {
    try {
      if (!this.openai || messages.length === 0) return null;

      const conversation = messages.join('\n');

      const response = await this.openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'Provide a concise summary of this conversation, highlighting key points and decisions made.'
          },
          {
            role: 'user',
            content: conversation
          }
        ],
        max_tokens: 200,
        temperature: 0.3
      });

      return response.choices[0].message.content;

    } catch (error) {
      logger.error('Error summarizing conversation:', error);
      return null;
    }
  }
}