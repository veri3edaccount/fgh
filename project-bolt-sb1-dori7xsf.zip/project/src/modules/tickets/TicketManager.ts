import { ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } from 'discord.js';
import { Guild } from '../../database/schemas/Guild.js';
import { logger } from '../../utils/logger.js';
import type { UltimateBot } from '../../index.js';

export class TicketManager {
  private bot: UltimateBot;

  constructor(bot: UltimateBot) {
    this.bot = bot;
  }

  async initialize() {
    logger.info('Ticket Manager initialized');
  }

  async handleTicketCreation(interaction: any) {
    try {
      const guildData = await Guild.findById(interaction.guild.id);
      
      if (!guildData?.tickets.enabled) {
        return interaction.reply({ 
          content: 'Ticket system is not configured!', 
          ephemeral: true 
        });
      }

      // Check if user already has an open ticket
      const existingTicket = interaction.guild.channels.cache.find((c: any) => 
        c.name === `ticket-${interaction.user.username.toLowerCase()}` || 
        c.name.startsWith('ticket-') && c.topic?.includes(interaction.user.id)
      );

      if (existingTicket) {
        return interaction.reply({ 
          content: `You already have an open ticket: ${existingTicket}`, 
          ephemeral: true 
        });
      }

      await interaction.deferReply({ ephemeral: true });

      // Create ticket channel
      const ticketChannel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username.toLowerCase()}`,
        type: ChannelType.GuildText,
        parent: guildData.tickets.category,
        topic: `Ticket created by ${interaction.user.tag} (${interaction.user.id})`,
        permissionOverwrites: [
          {
            id: interaction.guild.roles.everyone.id,
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id: interaction.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory
            ]
          },
          {
            id: this.bot.user?.id!,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory
            ]
          }
        ]
      });

      // Add support role permissions if configured
      if (guildData.tickets.supportRole) {
        await ticketChannel.permissionOverwrites.create(guildData.tickets.supportRole, {
          ViewChannel: true,
          SendMessages: true,
          ReadMessageHistory: true
        });
      }

      // Create welcome embed
      const welcomeEmbed = new EmbedBuilder()
        .setColor(0x0066FF)
        .setTitle('🎫 Support Ticket Created')
        .setDescription(`Hello ${interaction.user}! Thank you for creating a support ticket.\n\nPlease describe your issue in detail, and our support team will assist you shortly.`)
        .addFields(
          { name: '📋 Guidelines', value: '• Be patient and respectful\n• Provide as much detail as possible\n• Wait for a response before sending multiple messages', inline: false }
        )
        .setFooter({ text: 'Use the buttons below to manage this ticket' })
        .setTimestamp();

      const row = new ActionRowBuilder<ButtonBuilder>()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('close_ticket')
            .setLabel('Close Ticket')
            .setEmoji('🔒')
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId('ticket_transcript')
            .setLabel('Transcript')
            .setEmoji('📄')
            .setStyle(ButtonStyle.Secondary)
        );

      await ticketChannel.send({ 
        content: `${interaction.user} ${guildData.tickets.supportRole ? `<@&${guildData.tickets.supportRole}>` : ''}`,
        embeds: [welcomeEmbed], 
        components: [row] 
      });

      await interaction.editReply({ 
        content: `✅ Ticket created successfully! Please check ${ticketChannel}` 
      });

      // Log ticket creation
      logger.info(`Ticket created by ${interaction.user.tag} in ${interaction.guild.name}`);

    } catch (error) {
      logger.error('Error creating ticket:', error);
      await interaction.editReply({ 
        content: 'An error occurred while creating your ticket. Please try again later.' 
      });
    }
  }

  async closeTicket(channelId: string, closedBy: string, reason?: string) {
    try {
      const channel = this.bot.channels.cache.get(channelId);
      if (!channel || !channel.isTextBased()) return;

      // Generate transcript
      const messages = await channel.messages.fetch({ limit: 100 });
      const transcript = messages.reverse().map(msg => 
        `[${msg.createdAt.toLocaleString()}] ${msg.author.tag}: ${msg.content}`
      ).join('\n');

      // Save transcript (you might want to save this to a database or file)
      logger.info(`Ticket transcript for ${channel.name}:\n${transcript}`);

      // Delete channel after delay
      setTimeout(async () => {
        try {
          await channel.delete();
        } catch (error) {
          logger.error('Error deleting ticket channel:', error);
        }
      }, 5000);

    } catch (error) {
      logger.error('Error closing ticket:', error);
    }
  }
}