import { Collection } from 'discord.js';
import { User } from '../../database/schemas/User.js';
import { redisClient } from '../../database/connection.js';
import { logger } from '../../utils/logger.js';
import type { UltimateBot } from '../../index.js';

export class AnalyticsManager {
  private bot: UltimateBot;
  private messageCache = new Collection<string, number>();
  private commandCache = new Collection<string, number>();

  constructor(bot: UltimateBot) {
    this.bot = bot;
  }

  async initialize() {
    // Set up periodic data flushing
    setInterval(() => {
      this.flushAnalytics();
    }, 300000); // Flush every 5 minutes

    this.bot.on('messageCreate', this.trackMessage.bind(this));
    this.bot.on('voiceStateUpdate', this.trackVoiceActivity.bind(this));

    logger.info('Analytics Manager initialized');
  }

  private async trackMessage(message: any) {
    if (message.author.bot) return;

    const userId = message.author.id;
    const current = this.messageCache.get(userId) || 0;
    this.messageCache.set(userId, current + 1);

    // Track in Redis for real-time stats
    if (redisClient) {
      await redisClient.incr(`messages:${userId}:${new Date().toDateString()}`);
      await redisClient.incr(`messages:guild:${message.guild?.id}:${new Date().toDateString()}`);
    }
  }

  async trackCommand(userId: string, guildId: string, commandName: string) {
    const key = `${userId}:${commandName}`;
    const current = this.commandCache.get(key) || 0;
    this.commandCache.set(key, current + 1);

    // Track in Redis
    if (redisClient) {
      await redisClient.incr(`commands:${userId}:${new Date().toDateString()}`);
      await redisClient.incr(`commands:${commandName}:${new Date().toDateString()}`);
      await redisClient.incr(`commands:guild:${guildId}:${new Date().toDateString()}`);
    }
  }

  private async trackVoiceActivity(oldState: any, newState: any) {
    const userId = newState.id;
    
    // User joined a voice channel
    if (!oldState.channel && newState.channel) {
      if (redisClient) {
        await redisClient.set(`voice:${userId}:start`, Date.now());
      }
    }
    
    // User left a voice channel
    if (oldState.channel && !newState.channel) {
      if (redisClient) {
        const startTime = await redisClient.get(`voice:${userId}:start`);
        if (startTime) {
          const duration = Date.now() - parseInt(startTime);
          await redisClient.del(`voice:${userId}:start`);
          
          // Update user's voice time
          await User.findByIdAndUpdate(userId, {
            $inc: { 'experience.voiceTime': Math.floor(duration / 1000) }
          }, { upsert: true });
        }
      }
    }
  }

  private async flushAnalytics() {
    try {
      // Flush message counts
      for (const [userId, count] of this.messageCache) {
        await User.findByIdAndUpdate(userId, {
          $inc: { 
            'experience.messageCount': count,
            'experience.total': count * 10 // 10 XP per message
          }
        }, { upsert: true });
      }

      // Flush command counts
      for (const [key, count] of this.commandCache) {
        const [userId] = key.split(':');
        await User.findByIdAndUpdate(userId, {
          $inc: { 
            'experience.commandsUsed': count,
            'statistics.commandsUsed': count
          }
        }, { upsert: true });
      }

      // Clear caches
      this.messageCache.clear();
      this.commandCache.clear();

      logger.debug('Analytics data flushed to database');

    } catch (error) {
      logger.error('Error flushing analytics:', error);
    }
  }

  async getServerStats(guildId: string, days: number = 7): Promise<any> {
    try {
      const stats = {
        messages: 0,
        commands: 0,
        activeUsers: 0,
        topUsers: [],
        topCommands: []
      };

      if (!redisClient) return stats;

      // Get stats for the last N days
      for (let i = 0; i < days; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateString = date.toDateString();

        const messages = await redisClient.get(`messages:guild:${guildId}:${dateString}`);
        const commands = await redisClient.get(`commands:guild:${guildId}:${dateString}`);

        stats.messages += parseInt(messages || '0');
        stats.commands += parseInt(commands || '0');
      }

      return stats;

    } catch (error) {
      logger.error('Error getting server stats:', error);
      return null;
    }
  }

  async getUserStats(userId: string, days: number = 30): Promise<any> {
    try {
      const userData = await User.findById(userId);
      if (!userData) return null;

      const stats = {
        level: userData.experience.level,
        totalXP: userData.experience.total,
        messages: userData.experience.messageCount,
        voiceTime: userData.experience.voiceTime,
        commandsUsed: userData.experience.commandsUsed,
        gamesPlayed: userData.statistics.gamesPlayed,
        gamesWon: userData.statistics.gamesWon,
        winRate: userData.statistics.gamesPlayed > 0 ? 
          (userData.statistics.gamesWon / userData.statistics.gamesPlayed * 100).toFixed(1) : '0.0'
      };

      return stats;

    } catch (error) {
      logger.error('Error getting user stats:', error);
      return null;
    }
  }
}