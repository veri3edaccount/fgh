import axios from 'axios';
import { CronJob } from 'cron';
import { EmbedBuilder, TextChannel } from 'discord.js';
import { Guild } from '../../database/schemas/Guild.js';
import { logger } from '../../utils/logger.js';
import type { UltimateBot } from '../../index.js';

export class IntegrationManager {
  private bot: UltimateBot;
  private twitchJob?: CronJob;
  private youtubeJob?: CronJob;

  constructor(bot: UltimateBot) {
    this.bot = bot;
  }

  async initialize() {
    // Check Twitch streams every 2 minutes
    this.twitchJob = new CronJob('*/2 * * * *', this.checkTwitchStreams.bind(this), null, true);
    
    // Check YouTube videos every 10 minutes
    this.youtubeJob = new CronJob('*/10 * * * *', this.checkYouTubeVideos.bind(this), null, true);

    logger.info('Integration Manager initialized');
  }

  private async checkTwitchStreams() {
    try {
      if (!process.env.TWITCH_CLIENT_ID || !process.env.TWITCH_CLIENT_SECRET) return;

      // Get access token
      const tokenResponse = await axios.post('https://id.twitch.tv/oauth2/token', {
        client_id: process.env.TWITCH_CLIENT_ID,
        client_secret: process.env.TWITCH_CLIENT_SECRET,
        grant_type: 'client_credentials'
      });

      const accessToken = tokenResponse.data.access_token;

      // Get all guilds with Twitch integration enabled
      const guilds = await Guild.find({ 'integrations.twitch.enabled': true });

      for (const guild of guilds) {
        const discordGuild = this.bot.guilds.cache.get(guild._id);
        if (!discordGuild) continue;

        for (const streamConfig of guild.integrations.twitch.channels) {
          try {
            // Check if streamer is live
            const streamResponse = await axios.get(`https://api.twitch.tv/helix/streams`, {
              headers: {
                'Client-ID': process.env.TWITCH_CLIENT_ID,
                'Authorization': `Bearer ${accessToken}`
              },
              params: {
                user_login: streamConfig.username
              }
            });

            const streams = streamResponse.data.data;
            if (streams.length > 0) {
              const stream = streams[0];
              
              // Check if we've already announced this stream
              const cacheKey = `twitch:${streamConfig.username}:${stream.started_at}`;
              // You might want to use Redis or a database to store this
              
              const channel = discordGuild.channels.cache.get(streamConfig.discordChannel) as TextChannel;
              if (channel) {
                const embed = new EmbedBuilder()
                  .setColor(0x9146FF)
                  .setTitle(`🔴 ${stream.user_display_name} is now live!`)
                  .setDescription(stream.title)
                  .addFields(
                    { name: '🎮 Game', value: stream.game_name || 'Unknown', inline: true },
                    { name: '👥 Viewers', value: stream.viewer_count.toString(), inline: true }
                  )
                  .setURL(`https://twitch.tv/${streamConfig.username}`)
                  .setThumbnail(stream.thumbnail_url.replace('{width}', '320').replace('{height}', '180'))
                  .setTimestamp();

                await channel.send({ 
                  content: streamConfig.message || `${stream.user_display_name} is now live!`,
                  embeds: [embed] 
                });
              }
            }
          } catch (error) {
            logger.error(`Error checking Twitch stream for ${streamConfig.username}:`, error);
          }
        }
      }

    } catch (error) {
      logger.error('Error in Twitch integration:', error);
    }
  }

  private async checkYouTubeVideos() {
    try {
      if (!process.env.YOUTUBE_API_KEY) return;

      const guilds = await Guild.find({ 'integrations.youtube.enabled': true });

      for (const guild of guilds) {
        const discordGuild = this.bot.guilds.cache.get(guild._id);
        if (!discordGuild) continue;

        for (const channelConfig of guild.integrations.youtube.channels) {
          try {
            // Get latest videos from YouTube channel
            const response = await axios.get('https://www.googleapis.com/youtube/v3/search', {
              params: {
                key: process.env.YOUTUBE_API_KEY,
                channelId: channelConfig.channelId,
                part: 'snippet',
                order: 'date',
                maxResults: 1,
                publishedAfter: new Date(Date.now() - 15 * 60 * 1000).toISOString() // Last 15 minutes
              }
            });

            const videos = response.data.items;
            if (videos.length > 0) {
              const video = videos[0];
              
              const channel = discordGuild.channels.cache.get(channelConfig.discordChannel) as TextChannel;
              if (channel) {
                const embed = new EmbedBuilder()
                  .setColor(0xFF0000)
                  .setTitle(`📺 New video from ${video.snippet.channelTitle}`)
                  .setDescription(video.snippet.title)
                  .setURL(`https://youtube.com/watch?v=${video.id.videoId}`)
                  .setThumbnail(video.snippet.thumbnails.medium.url)
                  .setTimestamp(new Date(video.snippet.publishedAt));

                await channel.send({ 
                  content: channelConfig.message || 'New video uploaded!',
                  embeds: [embed] 
                });
              }
            }
          } catch (error) {
            logger.error(`Error checking YouTube channel ${channelConfig.channelId}:`, error);
          }
        }
      }

    } catch (error) {
      logger.error('Error in YouTube integration:', error);
    }
  }

  async addTwitchIntegration(guildId: string, username: string, discordChannelId: string, message?: string): Promise<boolean> {
    try {
      await Guild.findByIdAndUpdate(guildId, {
        $set: { 'integrations.twitch.enabled': true },
        $push: {
          'integrations.twitch.channels': {
            username,
            discordChannel: discordChannelId,
            message: message || `${username} is now live on Twitch!`
          }
        }
      }, { upsert: true });

      return true;
    } catch (error) {
      logger.error('Error adding Twitch integration:', error);
      return false;
    }
  }

  async addYouTubeIntegration(guildId: string, channelId: string, discordChannelId: string, message?: string): Promise<boolean> {
    try {
      await Guild.findByIdAndUpdate(guildId, {
        $set: { 'integrations.youtube.enabled': true },
        $push: {
          'integrations.youtube.channels': {
            channelId,
            discordChannel: discordChannelId,
            message: message || 'New video uploaded!'
          }
        }
      }, { upsert: true });

      return true;
    } catch (error) {
      logger.error('Error adding YouTube integration:', error);
      return false;
    }
  }

  async removeIntegration(guildId: string, type: 'twitch' | 'youtube', identifier: string): Promise<boolean> {
    try {
      const field = type === 'twitch' ? 'username' : 'channelId';
      
      await Guild.findByIdAndUpdate(guildId, {
        $pull: {
          [`integrations.${type}.channels`]: { [field]: identifier }
        }
      });

      return true;
    } catch (error) {
      logger.error(`Error removing ${type} integration:`, error);
      return false;
    }
  }
}