import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } from 'discord.js';
import { Guild } from '../../database/schemas/Guild.js';
import type { Command } from '../../managers/CommandManager.js';

export default {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket system management')
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Setup the ticket system')
        .addChannelOption(option =>
          option.setName('category')
            .setDescription('Category to create tickets in')
            .addChannelTypes(ChannelType.GuildCategory)
            .setRequired(true))
        .addRoleOption(option =>
          option.setName('support_role')
            .setDescription('Role that can view and manage tickets')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('panel')
        .setDescription('Create a ticket panel'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('close')
        .setDescription('Close the current ticket'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Add a user to the current ticket')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('User to add to the ticket')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('remove')
        .setDescription('Remove a user from the current ticket')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('User to remove from the ticket')
            .setRequired(true))),
  
  category: 'tickets',
  permissions: ['ManageChannels'],
  
  async execute(interaction, bot) {
    try {
      const subcommand = interaction.options.getSubcommand();

      if (!interaction.guild) {
        return interaction.reply({ content: 'This command can only be used in a server!', ephemeral: true });
      }

      switch (subcommand) {
        case 'setup':
          await handleSetup(interaction);
          break;
        case 'panel':
          await handlePanel(interaction);
          break;
        case 'close':
          await handleClose(interaction, bot);
          break;
        case 'add':
          await handleAdd(interaction);
          break;
        case 'remove':
          await handleRemove(interaction);
          break;
      }

    } catch (error) {
      console.error('Error in ticket command:', error);
      await interaction.reply({ 
        content: 'An error occurred while processing the ticket command.', 
        ephemeral: true 
      });
    }
  }
} as Command;

async function handleSetup(interaction: any) {
  const category = interaction.options.getChannel('category');
  const supportRole = interaction.options.getRole('support_role');

  // Update guild settings
  await Guild.findByIdAndUpdate(interaction.guild.id, {
    $set: {
      'tickets.enabled': true,
      'tickets.category': category.id,
      'tickets.supportRole': supportRole.id
    }
  }, { upsert: true });

  const embed = new EmbedBuilder()
    .setColor(0x00FF00)
    .setTitle('🎫 Ticket System Setup Complete')
    .addFields(
      { name: '📁 Category', value: category.name, inline: true },
      { name: '👥 Support Role', value: supportRole.name, inline: true }
    )
    .setDescription('Ticket system has been configured! Use `/ticket panel` to create a ticket panel.')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

async function handlePanel(interaction: any) {
  const guildData = await Guild.findById(interaction.guild.id);
  
  if (!guildData?.tickets.enabled) {
    return interaction.reply({ 
      content: 'Ticket system is not configured! Use `/ticket setup` first.', 
      ephemeral: true 
    });
  }

  const embed = new EmbedBuilder()
    .setColor(0x0066FF)
    .setTitle('🎫 Support Tickets')
    .setDescription('Need help? Click the button below to create a support ticket.\n\nOur support team will assist you as soon as possible!')
    .addFields(
      { name: '📋 Before Creating a Ticket', value: '• Check FAQ first\n• Be clear about your issue\n• Provide relevant details', inline: false }
    )
    .setFooter({ text: 'Click the button below to create a ticket' })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('create_ticket')
        .setLabel('Create Ticket')
        .setEmoji('🎫')
        .setStyle(ButtonStyle.Primary)
    );

  await interaction.reply({ embeds: [embed], components: [row] });
}

async function handleClose(interaction: any, bot: any) {
  const channel = interaction.channel;
  
  if (!channel?.name.startsWith('ticket-')) {
    return interaction.reply({ 
      content: 'This command can only be used in a ticket channel!', 
      ephemeral: true 
    });
  }

  const embed = new EmbedBuilder()
    .setColor(0xFF0000)
    .setTitle('🔒 Closing Ticket')
    .setDescription('This ticket will be closed in 5 seconds...')
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  setTimeout(async () => {
    try {
      await channel.delete();
    } catch (error) {
      console.error('Error deleting ticket channel:', error);
    }
  }, 5000);
}

async function handleAdd(interaction: any) {
  const user = interaction.options.getUser('user');
  const channel = interaction.channel;
  
  if (!channel?.name.startsWith('ticket-')) {
    return interaction.reply({ 
      content: 'This command can only be used in a ticket channel!', 
      ephemeral: true 
    });
  }

  try {
    await channel.permissionOverwrites.create(user, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true
    });

    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('✅ User Added')
      .setDescription(`${user} has been added to this ticket.`)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  } catch (error) {
    await interaction.reply({ 
      content: 'Failed to add user to ticket.', 
      ephemeral: true 
    });
  }
}

async function handleRemove(interaction: any) {
  const user = interaction.options.getUser('user');
  const channel = interaction.channel;
  
  if (!channel?.name.startsWith('ticket-')) {
    return interaction.reply({ 
      content: 'This command can only be used in a ticket channel!', 
      ephemeral: true 
    });
  }

  try {
    await channel.permissionOverwrites.delete(user);

    const embed = new EmbedBuilder()
      .setColor(0xFF0000)
      .setTitle('❌ User Removed')
      .setDescription(`${user} has been removed from this ticket.`)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  } catch (error) {
    await interaction.reply({ 
      content: 'Failed to remove user from ticket.', 
      ephemeral: true 
    });
  }
}