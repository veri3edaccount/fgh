import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { User } from '../../database/schemas/User.js';
import type { Command } from '../../managers/CommandManager.js';

const SLOT_EMOJIS = ['🍎', '🍊', '🍋', '🍇', '🍓', '🍒', '💎', '⭐'];
const WINNING_COMBINATIONS = {
  '💎💎💎': 50,
  '⭐⭐⭐': 25,
  '🍒🍒🍒': 15,
  '🍓🍓🍓': 10,
  '🍇🍇🍇': 8,
  '🍋🍋🍋': 6,
  '🍊🍊🍊': 4,
  '🍎🍎🍎': 2
};

export default {
  data: new SlashCommandBuilder()
    .setName('slots')
    .setDescription('Play the slot machine')
    .addIntegerOption(option =>
      option.setName('bet')
        .setDescription('Amount to bet')
        .setRequired(true)
        .setMinValue(10)),
  
  category: 'fun',
  cooldown: 3,
  
  async execute(interaction, bot) {
    try {
      const bet = interaction.options.getInteger('bet', true);
      
      // Get user data
      let userData = await User.findById(interaction.user.id);
      if (!userData) {
        userData = new User({
          _id: interaction.user.id,
          username: interaction.user.username,
          discriminator: interaction.user.discriminator,
          avatar: interaction.user.avatar
        });
        await userData.save();
      }

      // Check if user has enough balance
      if (userData.economy.balance < bet) {
        const embed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Insufficient Funds')
          .setDescription(`You need **${bet.toLocaleString()}** coins to play, but you only have **${userData.economy.balance.toLocaleString()}** coins.`);

        return interaction.reply({ embeds: [embed] });
      }

      // Generate slot results
      const slots = [
        SLOT_EMOJIS[Math.floor(Math.random() * SLOT_EMOJIS.length)],
        SLOT_EMOJIS[Math.floor(Math.random() * SLOT_EMOJIS.length)],
        SLOT_EMOJIS[Math.floor(Math.random() * SLOT_EMOJIS.length)]
      ];

      const slotString = slots.join('');
      let winAmount = 0;
      let isWin = false;

      // Check for wins
      if (WINNING_COMBINATIONS[slotString]) {
        winAmount = bet * WINNING_COMBINATIONS[slotString];
        isWin = true;
      } else if (slots[0] === slots[1] || slots[1] === slots[2] || slots[0] === slots[2]) {
        // Two matching symbols - small win
        winAmount = Math.floor(bet * 0.5);
        isWin = true;
      }

      // Update user balance
      const netGain = winAmount - bet;
      userData.economy.balance += netGain;
      userData.statistics.gamesPlayed += 1;
      
      if (isWin) {
        userData.statistics.gamesWon += 1;
        userData.statistics.totalWinnings += winAmount;
        userData.economy.totalEarned += winAmount;
      }
      
      userData.economy.totalSpent += bet;
      await userData.save();

      // Create result embed
      const embed = new EmbedBuilder()
        .setTitle('🎰 Slot Machine')
        .setDescription(`
          ╔═══════════╗
          ║ ${slots[0]} ║ ${slots[1]} ║ ${slots[2]} ║
          ╚═══════════╝
        `)
        .addFields(
          { name: '💰 Bet', value: `${bet.toLocaleString()} coins`, inline: true },
          { name: isWin ? '🎉 Won' : '💸 Lost', value: isWin ? `${winAmount.toLocaleString()} coins` : `${bet.toLocaleString()} coins`, inline: true },
          { name: '📊 Net', value: `${netGain >= 0 ? '+' : ''}${netGain.toLocaleString()} coins`, inline: true },
          { name: '💵 New Balance', value: `${userData.economy.balance.toLocaleString()} coins`, inline: false }
        )
        .setColor(isWin ? 0x00FF00 : 0xFF0000)
        .setTimestamp();

      if (isWin && WINNING_COMBINATIONS[slotString]) {
        embed.setFooter({ text: `🎊 JACKPOT! ${WINNING_COMBINATIONS[slotString]}x multiplier!` });
      }

      await interaction.reply({ embeds: [embed] });

    } catch (error) {
      console.error('Error in slots command:', error);
      await interaction.reply({ 
        content: 'An error occurred while playing slots.', 
        ephemeral: true 
      });
    }
  }
} as Command;