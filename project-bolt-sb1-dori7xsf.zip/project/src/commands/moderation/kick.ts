import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from 'discord.js';
import { User } from '../../database/schemas/User.js';
import { logger } from '../../utils/logger.js';
import type { Command } from '../../managers/CommandManager.js';

export default {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a user from the server')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to kick')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the kick')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  
  category: 'moderation',
  permissions: ['KickMembers'],
  
  async execute(interaction, bot) {
    try {
      const target = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'No reason provided';

      if (!interaction.guild) {
        return interaction.reply({ content: 'This command can only be used in a server!', ephemeral: true });
      }

      // Check if user is trying to kick themselves
      if (target.id === interaction.user.id) {
        return interaction.reply({ content: 'You cannot kick yourself!', ephemeral: true });
      }

      // Check if user is trying to kick the bot
      if (target.id === bot.user?.id) {
        return interaction.reply({ content: 'I cannot kick myself!', ephemeral: true });
      }

      // Get guild member
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      
      if (!member) {
        return interaction.reply({ content: 'User is not in this server!', ephemeral: true });
      }

      // Check role hierarchy
      if (member.roles.highest.position >= interaction.member.roles.highest.position) {
        return interaction.reply({ 
          content: 'You cannot kick someone with an equal or higher role!', 
          ephemeral: true 
        });
      }

      // Check if bot can kick the member
      if (!member.kickable) {
        return interaction.reply({ 
          content: 'I cannot kick this user! They may have higher permissions than me.', 
          ephemeral: true 
        });
      }

      // Kick the user
      await member.kick(`${reason} - Kicked by ${interaction.user.tag}`);

      // Update user record
      await User.findByIdAndUpdate(target.id, {
        $push: {
          'moderation.kicks': {
            reason,
            moderator: interaction.user.id,
            date: new Date(),
            guildId: interaction.guild.id
          }
        }
      }, { upsert: true });

      // Create embed
      const embed = new EmbedBuilder()
        .setColor(0xFFA500)
        .setTitle('👢 User Kicked')
        .addFields(
          { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
          { name: 'Moderator', value: interaction.user.tag, inline: true },
          { name: 'Reason', value: reason, inline: true }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

      // Log the action
      logger.info(`User ${target.tag} kicked from ${interaction.guild.name} by ${interaction.user.tag}. Reason: ${reason}`);

    } catch (error) {
      logger.error('Error in kick command:', error);
      await interaction.reply({ 
        content: 'An error occurred while trying to kick the user.', 
        ephemeral: true 
      });
    }
  }
} as Command;