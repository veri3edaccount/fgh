import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from 'discord.js';
import { User } from '../../database/schemas/User.js';
import { logger } from '../../utils/logger.js';
import type { Command } from '../../managers/CommandManager.js';

export default {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a user from the server')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to ban')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the ban')
        .setRequired(false))
    .addIntegerOption(option =>
      option.setName('delete_days')
        .setDescription('Days of messages to delete (0-7)')
        .setMinValue(0)
        .setMaxValue(7)
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  
  category: 'moderation',
  permissions: ['BanMembers'],
  
  async execute(interaction, bot) {
    try {
      const target = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'No reason provided';
      const deleteDays = interaction.options.getInteger('delete_days') || 0;

      if (!interaction.guild) {
        return interaction.reply({ content: 'This command can only be used in a server!', ephemeral: true });
      }

      // Check if user is trying to ban themselves
      if (target.id === interaction.user.id) {
        return interaction.reply({ content: 'You cannot ban yourself!', ephemeral: true });
      }

      // Check if user is trying to ban the bot
      if (target.id === bot.user?.id) {
        return interaction.reply({ content: 'I cannot ban myself!', ephemeral: true });
      }

      // Get guild member
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      
      if (member) {
        // Check role hierarchy
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
          return interaction.reply({ 
            content: 'You cannot ban someone with an equal or higher role!', 
            ephemeral: true 
          });
        }

        // Check if bot can ban the member
        if (!member.bannable) {
          return interaction.reply({ 
            content: 'I cannot ban this user! They may have higher permissions than me.', 
            ephemeral: true 
          });
        }
      }

      // Ban the user
      await interaction.guild.members.ban(target, {
        reason: `${reason} - Banned by ${interaction.user.tag}`,
        deleteMessageSeconds: deleteDays * 24 * 60 * 60
      });

      // Update user record
      await User.findByIdAndUpdate(target.id, {
        $push: {
          'moderation.bans': {
            reason,
            moderator: interaction.user.id,
            date: new Date(),
            guildId: interaction.guild.id
          }
        }
      }, { upsert: true });

      // Create embed
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('🔨 User Banned')
        .addFields(
          { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
          { name: 'Moderator', value: interaction.user.tag, inline: true },
          { name: 'Reason', value: reason, inline: true }
        )
        .setTimestamp();

      if (deleteDays > 0) {
        embed.addFields({ name: 'Messages Deleted', value: `${deleteDays} day(s)`, inline: true });
      }

      await interaction.reply({ embeds: [embed] });

      // Log the action
      logger.info(`User ${target.tag} banned from ${interaction.guild.name} by ${interaction.user.tag}. Reason: ${reason}`);

    } catch (error) {
      logger.error('Error in ban command:', error);
      await interaction.reply({ 
        content: 'An error occurred while trying to ban the user.', 
        ephemeral: true 
      });
    }
  }
} as Command;