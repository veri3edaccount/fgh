import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { User } from '../../database/schemas/User.js';
import type { Command } from '../../managers/CommandManager.js';

export default {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your or another user\'s balance')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('User to check balance for')
        .setRequired(false)),
  
  category: 'economy',
  cooldown: 5,
  
  async execute(interaction, bot) {
    try {
      const target = interaction.options.getUser('user') || interaction.user;
      
      // Get or create user data
      let userData = await User.findById(target.id);
      if (!userData) {
        userData = new User({
          _id: target.id,
          username: target.username,
          discriminator: target.discriminator,
          avatar: target.avatar
        });
        await userData.save();
      }

      const { balance, bank, totalEarned, totalSpent } = userData.economy;
      const totalWealth = balance + bank;

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle(`💰 ${target.username}'s Balance`)
        .setThumbnail(target.displayAvatarURL())
        .addFields(
          { name: '💵 Wallet', value: `${balance.toLocaleString()} coins`, inline: true },
          { name: '🏦 Bank', value: `${bank.toLocaleString()} coins`, inline: true },
          { name: '💎 Total Wealth', value: `${totalWealth.toLocaleString()} coins`, inline: true },
          { name: '📈 Total Earned', value: `${totalEarned.toLocaleString()} coins`, inline: true },
          { name: '📉 Total Spent', value: `${totalSpent.toLocaleString()} coins`, inline: true },
          { name: '💰 Net Worth', value: `${(totalEarned - totalSpent).toLocaleString()} coins`, inline: true }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

    } catch (error) {
      console.error('Error in balance command:', error);
      await interaction.reply({ 
        content: 'An error occurred while checking the balance.', 
        ephemeral: true 
      });
    }
  }
} as Command;