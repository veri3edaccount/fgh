import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { User } from '../../database/schemas/User.js';
import { Guild } from '../../database/schemas/Guild.js';
import type { Command } from '../../managers/CommandManager.js';

export default {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily reward'),
  
  category: 'economy',
  cooldown: 5,
  
  async execute(interaction, bot) {
    try {
      // Get guild settings
      const guildData = await Guild.findById(interaction.guild?.id);
      const dailyAmount = guildData?.economy.dailyAmount || 1000;
      const currency = guildData?.economy.currency || '💰';

      // Get or create user data
      let userData = await User.findById(interaction.user.id);
      if (!userData) {
        userData = new User({
          _id: interaction.user.id,
          username: interaction.user.username,
          discriminator: interaction.user.discriminator,
          avatar: interaction.user.avatar
        });
      }

      const now = new Date();
      const lastDaily = userData.economy.lastDaily;

      // Check if user has already claimed today
      if (lastDaily && now.getTime() - lastDaily.getTime() < 24 * 60 * 60 * 1000) {
        const timeLeft = 24 * 60 * 60 * 1000 - (now.getTime() - lastDaily.getTime());
        const hoursLeft = Math.floor(timeLeft / (60 * 60 * 1000));
        const minutesLeft = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));

        const embed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('⏰ Daily Already Claimed')
          .setDescription(`You've already claimed your daily reward! Come back in **${hoursLeft}h ${minutesLeft}m**.`)
          .setTimestamp();

        return interaction.reply({ embeds: [embed] });
      }

      // Calculate streak bonus
      let streakBonus = 0;
      if (lastDaily) {
        const daysSinceLastDaily = Math.floor((now.getTime() - lastDaily.getTime()) / (24 * 60 * 60 * 1000));
        if (daysSinceLastDaily === 1) {
          userData.economy.dailyStreak += 1;
        } else {
          userData.economy.dailyStreak = 1;
        }
      } else {
        userData.economy.dailyStreak = 1;
      }

      // Calculate bonus (10% per streak day, max 100%)
      const streakMultiplier = Math.min(userData.economy.dailyStreak * 0.1, 1);
      streakBonus = Math.floor(dailyAmount * streakMultiplier);
      const totalAmount = dailyAmount + streakBonus;

      // Update user data
      userData.economy.balance += totalAmount;
      userData.economy.totalEarned += totalAmount;
      userData.economy.lastDaily = now;
      await userData.save();

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle(`${currency} Daily Reward Claimed!`)
        .addFields(
          { name: '💰 Base Amount', value: `${dailyAmount.toLocaleString()} coins`, inline: true },
          { name: '🔥 Streak Bonus', value: `${streakBonus.toLocaleString()} coins`, inline: true },
          { name: '💎 Total Received', value: `${totalAmount.toLocaleString()} coins`, inline: true },
          { name: '📊 Current Streak', value: `${userData.economy.dailyStreak} day(s)`, inline: true },
          { name: '💵 New Balance', value: `${userData.economy.balance.toLocaleString()} coins`, inline: true }
        )
        .setFooter({ text: 'Come back tomorrow for another reward!' })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

    } catch (error) {
      console.error('Error in daily command:', error);
      await interaction.reply({ 
        content: 'An error occurred while claiming your daily reward.', 
        ephemeral: true 
      });
    }
  }
} as Command;