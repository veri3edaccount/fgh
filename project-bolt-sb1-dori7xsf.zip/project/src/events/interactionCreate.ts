import { logger } from '../utils/logger.js';
import type { Event } from '../managers/EventManager.js';
import type { UltimateBot } from '../index.js';

export default {
  name: 'interactionCreate',
  
  async execute(interaction, bot: UltimateBot) {
    if (interaction.isChatInputCommand()) {
      const command = bot.commands.get(interaction.commandName);

      if (!command) {
        logger.warn(`No command matching ${interaction.commandName} was found.`);
        return;
      }

      // Check cooldowns
      const { cooldowns } = bot;
      if (!cooldowns.has(command.data.name)) {
        cooldowns.set(command.data.name, new Map());
      }

      const now = Date.now();
      const timestamps = cooldowns.get(command.data.name);
      const cooldownAmount = (command.cooldown ?? 3) * 1000;

      if (timestamps?.has(interaction.user.id)) {
        const expirationTime = timestamps.get(interaction.user.id)! + cooldownAmount;

        if (now < expirationTime) {
          const expiredTimestamp = Math.round(expirationTime / 1000);
          return interaction.reply({ 
            content: `Please wait, you are on a cooldown for \`${command.data.name}\`. You can use it again <t:${expiredTimestamp}:R>.`, 
            ephemeral: true 
          });
        }
      }

      timestamps?.set(interaction.user.id, now);
      setTimeout(() => timestamps?.delete(interaction.user.id), cooldownAmount);

      try {
        await command.execute(interaction, bot);
        
        // Track command usage
        bot.analyticsManager?.trackCommand(interaction.user.id, interaction.guildId!, command.data.name);
      } catch (error) {
        logger.error(`Error executing ${interaction.commandName}:`, error);
        
        const reply = { 
          content: 'There was an error while executing this command!', 
          ephemeral: true 
        };
        
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(reply);
        } else {
          await interaction.reply(reply);
        }
      }
    } else if (interaction.isButton()) {
      // Handle button interactions
      if (interaction.customId === 'create_ticket') {
        await bot.ticketManager?.handleTicketCreation(interaction);
      }
    } else if (interaction.isStringSelectMenu()) {
      // Handle select menu interactions
      // Add your select menu handling logic here
    }
  }
} as Event;