import { ActivityType } from 'discord.js';
import { logger } from '../utils/logger.js';
import type { Event } from '../managers/EventManager.js';

export default {
  name: 'ready',
  once: true,
  
  async execute(bot) {
    logger.info(`${bot.user?.tag} is now online and ready!`);
    logger.info(`Serving ${bot.guilds.cache.size} servers with ${bot.users.cache.size} users`);

    // Set bot activity
    const activities = [
      { name: 'your server 🛡️', type: ActivityType.Watching },
      { name: 'with advanced AI 🤖', type: ActivityType.Playing },
      { name: '/help for commands 📚', type: ActivityType.Listening },
      { name: 'the community grow 🌱', type: ActivityType.Watching }
    ];

    let activityIndex = 0;
    const updateActivity = () => {
      bot.user?.setActivity(activities[activityIndex]);
      activityIndex = (activityIndex + 1) % activities.length;
    };

    updateActivity();
    setInterval(updateActivity, 30000); // Change every 30 seconds

    // Initialize all systems
    logger.info('All systems initialized and ready!');
  }
} as Event;