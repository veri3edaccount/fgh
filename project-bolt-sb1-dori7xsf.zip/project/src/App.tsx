import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Shield, Bot, Zap, Users, BarChart3, Settings, LogOut, Menu, X } from 'lucide-react';
import Dashboard from './components/Dashboard';
import GuildSettings from './components/GuildSettings';
import Analytics from './components/Analytics';
import Login from './components/Login';

interface User {
  userId: string;
  username: string;
  avatar: string;
  guilds: Array<{
    id: string;
    name: string;
    icon: string;
    permissions: number;
  }>;
}

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = localStorage.getItem('token') || new URLSearchParams(window.location.search).get('token');
    
    if (token) {
      localStorage.setItem('token', token);
      
      try {
        const response = await fetch('/api/auth/me', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        } else {
          localStorage.removeItem('token');
        }
      } catch (error) {
        console.error('Auth check failed:', error);
        localStorage.removeItem('token');
      }
    }
    
    setLoading(false);
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
    window.location.href = '/';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-900 text-white">
        {/* Mobile menu button */}
        <div className="lg:hidden fixed top-4 left-4 z-50">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-md bg-gray-800 text-gray-300 hover:text-white hover:bg-gray-700"
          >
            {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Sidebar */}
        <div className={`fixed inset-y-0 left-0 z-40 w-64 bg-gray-800 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 ease-in-out`}>
          <div className="flex flex-col h-full">
            {/* Logo */}
            <div className="flex items-center px-6 py-4 border-b border-gray-700">
              <Bot className="h-8 w-8 text-blue-500 mr-3" />
              <h1 className="text-xl font-bold">Ultimate Bot</h1>
            </div>

            {/* User info */}
            <div className="px-6 py-4 border-b border-gray-700">
              <div className="flex items-center">
                <img
                  src={user.avatar ? `https://cdn.discordapp.com/avatars/${user.userId}/${user.avatar}.png` : '/default-avatar.png'}
                  alt="Avatar"
                  className="h-10 w-10 rounded-full mr-3"
                />
                <div>
                  <p className="font-medium">{user.username}</p>
                  <p className="text-sm text-gray-400">{user.guilds.length} servers</p>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex-1 px-6 py-4">
              <div className="space-y-2">
                <a href="/dashboard" className="flex items-center px-3 py-2 rounded-md text-gray-300 hover:text-white hover:bg-gray-700">
                  <BarChart3 className="h-5 w-5 mr-3" />
                  Dashboard
                </a>
                <a href="/guilds" className="flex items-center px-3 py-2 rounded-md text-gray-300 hover:text-white hover:bg-gray-700">
                  <Users className="h-5 w-5 mr-3" />
                  Servers
                </a>
                <a href="/analytics" className="flex items-center px-3 py-2 rounded-md text-gray-300 hover:text-white hover:bg-gray-700">
                  <BarChart3 className="h-5 w-5 mr-3" />
                  Analytics
                </a>
                <a href="/settings" className="flex items-center px-3 py-2 rounded-md text-gray-300 hover:text-white hover:bg-gray-700">
                  <Settings className="h-5 w-5 mr-3" />
                  Settings
                </a>
              </div>
            </nav>

            {/* Logout */}
            <div className="px-6 py-4 border-t border-gray-700">
              <button
                onClick={logout}
                className="flex items-center w-full px-3 py-2 rounded-md text-gray-300 hover:text-white hover:bg-gray-700"
              >
                <LogOut className="h-5 w-5 mr-3" />
                Logout
              </button>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="lg:ml-64">
          <div className="p-6">
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" />} />
              <Route path="/dashboard" element={<Dashboard user={user} />} />
              <Route path="/guild/:guildId" element={<GuildSettings user={user} />} />
              <Route path="/analytics" element={<Analytics user={user} />} />
            </Routes>
          </div>
        </div>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-30 bg-black bg-opacity-50 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          ></div>
        )}
      </div>
    </Router>
  );
}

export default App;