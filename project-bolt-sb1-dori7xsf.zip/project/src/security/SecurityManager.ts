import { Collection, GuildMember, TextChannel } from 'discord.js';
import { Guild } from '../database/schemas/Guild.js';
import { User } from '../database/schemas/User.js';
import { logger } from '../utils/logger.js';
import type { UltimateBot } from '../index.js';

export class SecurityManager {
  private bot: UltimateBot;
  private joinTracker = new Collection<string, Array<{ userId: string; timestamp: number }>>();
  private suspiciousIPs = new Set<string>();

  constructor(bot: UltimateBot) {
    this.bot = bot;
  }

  async initialize() {
    this.bot.on('guildMemberAdd', this.handleMemberJoin.bind(this));
    this.bot.on('messageCreate', this.handleMessage.bind(this));
    logger.info('Security Manager initialized');
  }

  private async handleMemberJoin(member: GuildMember) {
    const guildId = member.guild.id;
    
    // Initialize tracker for guild if not exists
    if (!this.joinTracker.has(guildId)) {
      this.joinTracker.set(guildId, []);
    }

    const joins = this.joinTracker.get(guildId)!;
    const now = Date.now();
    
    // Add current join
    joins.push({ userId: member.id, timestamp: now });

    // Get guild settings
    const guildData = await Guild.findById(guildId);
    if (!guildData?.moderation.antiRaid.enabled) return;

    const { joinThreshold, timeWindow, action } = guildData.moderation.antiRaid;
    const windowStart = now - (timeWindow * 1000);

    // Filter recent joins
    const recentJoins = joins.filter(join => join.timestamp > windowStart);
    
    // Update tracker
    this.joinTracker.set(guildId, recentJoins);

    // Check if threshold exceeded
    if (recentJoins.length >= joinThreshold) {
      logger.warn(`Anti-raid triggered in ${member.guild.name}: ${recentJoins.length} joins in ${timeWindow}s`);
      await this.executeAntiRaidAction(member.guild, recentJoins, action);
    }

    // Check for suspicious account patterns
    await this.checkSuspiciousAccount(member);
  }

  private async executeAntiRaidAction(guild: any, recentJoins: Array<{ userId: string; timestamp: number }>, action: string) {
    const logChannel = await this.getLogChannel(guild.id);

    switch (action) {
      case 'kick':
        for (const join of recentJoins) {
          try {
            const member = await guild.members.fetch(join.userId);
            await member.kick('Anti-raid protection triggered');
          } catch (error) {
            logger.error(`Failed to kick ${join.userId}:`, error);
          }
        }
        break;

      case 'ban':
        for (const join of recentJoins) {
          try {
            await guild.members.ban(join.userId, { reason: 'Anti-raid protection triggered' });
          } catch (error) {
            logger.error(`Failed to ban ${join.userId}:`, error);
          }
        }
        break;

      case 'lockdown':
        await this.lockdownServer(guild);
        break;
    }

    if (logChannel) {
      await logChannel.send({
        content: `🚨 **Anti-Raid Protection Activated**\n` +
                `Action: ${action}\n` +
                `Affected users: ${recentJoins.length}\n` +
                `Time window: Last 60 seconds`
      });
    }
  }

  private async checkSuspiciousAccount(member: GuildMember) {
    const accountAge = Date.now() - member.user.createdTimestamp;
    const daysSinceCreation = accountAge / (1000 * 60 * 60 * 24);

    // Flag accounts younger than 7 days
    if (daysSinceCreation < 7) {
      const logChannel = await this.getLogChannel(member.guild.id);
      if (logChannel) {
        await logChannel.send({
          content: `⚠️ **Suspicious Account Detected**\n` +
                  `User: ${member.user.tag} (${member.id})\n` +
                  `Account created: ${Math.round(daysSinceCreation)} days ago\n` +
                  `Consider manual review.`
        });
      }
    }

    // Check for alt account patterns
    await this.checkAltAccount(member);
  }

  private async checkAltAccount(member: GuildMember) {
    // Check for similar usernames in the server
    const similarUsers = member.guild.members.cache.filter(m => 
      m.user.username.toLowerCase().includes(member.user.username.toLowerCase().substring(0, 4)) ||
      member.user.username.toLowerCase().includes(m.user.username.toLowerCase().substring(0, 4))
    );

    if (similarUsers.size > 1) {
      const logChannel = await this.getLogChannel(member.guild.id);
      if (logChannel) {
        await logChannel.send({
          content: `🔍 **Potential Alt Account**\n` +
                  `New user: ${member.user.tag}\n` +
                  `Similar usernames found: ${similarUsers.size}\n` +
                  `Manual review recommended.`
        });
      }
    }
  }

  private async handleMessage(message: any) {
    if (message.author.bot || !message.guild) return;

    const guildData = await Guild.findById(message.guild.id);
    if (!guildData?.moderation.automod.enabled) return;

    // Run automod checks
    await this.runAutomodChecks(message, guildData);
  }

  private async runAutomodChecks(message: any, guildData: any) {
    const { automod } = guildData.moderation;
    let violations = 0;
    const reasons = [];

    // Profanity filter
    if (automod.filterProfanity && this.containsProfanity(message.content)) {
      violations++;
      reasons.push('Profanity');
    }

    // Spam detection
    if (automod.filterSpam && await this.isSpam(message)) {
      violations++;
      reasons.push('Spam');
    }

    // Invite filter
    if (automod.filterInvites && this.containsInvite(message.content)) {
      violations++;
      reasons.push('Discord invite');
    }

    // Link filter
    if (automod.filterLinks && this.containsLink(message.content)) {
      violations++;
      reasons.push('External link');
    }

    if (violations > 0) {
      await this.handleAutomodViolation(message, reasons, violations, automod);
    }
  }

  private containsProfanity(content: string): boolean {
    const profanityWords = ['damn', 'hell', 'crap']; // Add more words as needed
    return profanityWords.some(word => content.toLowerCase().includes(word));
  }

  private async isSpam(message: any): Promise<boolean> {
    // Simple spam detection - check for repeated messages
    const userMessages = message.channel.messages.cache
      .filter((m: any) => m.author.id === message.author.id && m.createdTimestamp > Date.now() - 10000)
      .map((m: any) => m.content);

    return userMessages.filter((content: string) => content === message.content).length > 3;
  }

  private containsInvite(content: string): boolean {
    const inviteRegex = /(discord\.gg|discord\.com\/invite|discordapp\.com\/invite)/i;
    return inviteRegex.test(content);
  }

  private containsLink(content: string): boolean {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return urlRegex.test(content);
  }

  private async handleAutomodViolation(message: any, reasons: string[], violations: number, automodConfig: any) {
    try {
      // Delete the message
      await message.delete();

      // Update user warnings
      await User.findByIdAndUpdate(message.author.id, {
        $push: {
          'moderation.warnings': {
            reason: `Automod: ${reasons.join(', ')}`,
            moderator: this.bot.user?.id,
            date: new Date(),
            guildId: message.guild.id
          }
        }
      }, { upsert: true });

      // Get user's warning count
      const userData = await User.findById(message.author.id);
      const warningCount = userData?.moderation.warnings.filter(w => w.guildId === message.guild.id).length || 0;

      // Apply punishments based on warning count
      if (warningCount >= automodConfig.banThreshold) {
        await message.member.ban({ reason: `Automod: Exceeded ${automodConfig.banThreshold} warnings` });
      } else if (warningCount >= automodConfig.muteThreshold) {
        const guildData = await Guild.findById(message.guild.id);
        if (guildData?.moderation.mutedRole) {
          await message.member.roles.add(guildData.moderation.mutedRole);
        }
      }

      // Log the action
      const logChannel = await this.getLogChannel(message.guild.id);
      if (logChannel) {
        await logChannel.send({
          content: `🛡️ **Automod Action**\n` +
                  `User: ${message.author.tag}\n` +
                  `Violations: ${reasons.join(', ')}\n` +
                  `Total warnings: ${warningCount}\n` +
                  `Message deleted`
        });
      }

    } catch (error) {
      logger.error('Error handling automod violation:', error);
    }
  }

  private async lockdownServer(guild: any) {
    try {
      const channels = guild.channels.cache.filter((c: any) => c.isTextBased());
      
      for (const [, channel] of channels) {
        await channel.permissionOverwrites.edit(guild.roles.everyone, {
          SendMessages: false
        });
      }

      logger.info(`Server ${guild.name} locked down due to raid`);
    } catch (error) {
      logger.error('Error locking down server:', error);
    }
  }

  private async getLogChannel(guildId: string): Promise<TextChannel | null> {
    try {
      const guildData = await Guild.findById(guildId);
      if (!guildData?.moderation.logChannel) return null;

      const guild = this.bot.guilds.cache.get(guildId);
      if (!guild) return null;

      const channel = guild.channels.cache.get(guildData.moderation.logChannel) as TextChannel;
      return channel || null;
    } catch (error) {
      return null;
    }
  }
}