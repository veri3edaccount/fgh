import { readdirSync } from 'fs';
import { join } from 'path';
import { pathToFileURL } from 'url';
import { logger } from '../utils/logger.js';
import type { UltimateBot } from '../index.js';

export interface Event {
  name: string;
  once?: boolean;
  execute: (...args: any[]) => Promise<void>;
}

export class EventManager {
  private bot: UltimateBot;

  constructor(bot: UltimateBot) {
    this.bot = bot;
  }

  async loadEvents() {
    const eventsPath = join(process.cwd(), 'src', 'events');
    const eventFiles = readdirSync(eventsPath).filter(file => 
      file.endsWith('.ts') || file.endsWith('.js')
    );

    for (const file of eventFiles) {
      const filePath = join(eventsPath, file);
      const fileUrl = pathToFileURL(filePath).href;
      
      try {
        const eventModule = await import(fileUrl);
        const event: Event = eventModule.default || eventModule;

        if (event.once) {
          this.bot.once(event.name, (...args) => event.execute(...args, this.bot));
        } else {
          this.bot.on(event.name, (...args) => event.execute(...args, this.bot));
        }

        logger.info(`Loaded event: ${event.name}`);
      } catch (error) {
        logger.error(`Error loading event ${file}:`, error);
      }
    }
  }
}