import { Collection, REST, Routes, SlashCommandBuilder } from 'discord.js';
import { readdirSync } from 'fs';
import { join } from 'path';
import { pathToFileURL } from 'url';
import { logger } from '../utils/logger.js';
import type { UltimateBot } from '../index.js';

export interface Command {
  data: SlashCommandBuilder;
  category: string;
  permissions?: string[];
  cooldown?: number;
  execute: (interaction: any, bot: UltimateBot) => Promise<void>;
}

export class CommandManager {
  private bot: UltimateBot;
  private commands: Collection<string, Command> = new Collection();

  constructor(bot: UltimateBot) {
    this.bot = bot;
  }

  async loadCommands() {
    const commandsPath = join(process.cwd(), 'src', 'commands');
    const commandFolders = readdirSync(commandsPath);

    for (const folder of commandFolders) {
      const folderPath = join(commandsPath, folder);
      const commandFiles = readdirSync(folderPath).filter(file => 
        file.endsWith('.ts') || file.endsWith('.js')
      );

      for (const file of commandFiles) {
        const filePath = join(folderPath, file);
        const fileUrl = pathToFileURL(filePath).href;
        
        try {
          const commandModule = await import(fileUrl);
          const command: Command = commandModule.default || commandModule;

          if ('data' in command && 'execute' in command) {
            command.category = folder;
            this.commands.set(command.data.name, command);
            this.bot.commands.set(command.data.name, command);
            logger.info(`Loaded command: ${command.data.name}`);
          } else {
            logger.warn(`Command ${file} is missing required properties`);
          }
        } catch (error) {
          logger.error(`Error loading command ${file}:`, error);
        }
      }
    }

    await this.deployCommands();
  }

  private async deployCommands() {
    try {
      const rest = new REST().setToken(process.env.DISCORD_TOKEN!);
      const commands = Array.from(this.commands.values()).map(cmd => cmd.data.toJSON());

      logger.info(`Started refreshing ${commands.length} application (/) commands.`);

      await rest.put(
        Routes.applicationCommands(process.env.DISCORD_CLIENT_ID!),
        { body: commands }
      );

      logger.info(`Successfully reloaded ${commands.length} application (/) commands.`);
    } catch (error) {
      logger.error('Error deploying commands:', error);
    }
  }

  getCommand(name: string): Command | undefined {
    return this.commands.get(name);
  }

  getAllCommands(): Collection<string, Command> {
    return this.commands;
  }

  async reloadCommand(commandName: string) {
    const command = this.commands.get(commandName);
    if (!command) return false;

    try {
      delete require.cache[require.resolve(`../commands/${command.category}/${commandName}.ts`)];
      const newCommand = await import(`../commands/${command.category}/${commandName}.ts`);
      
      this.commands.set(commandName, newCommand.default || newCommand);
      this.bot.commands.set(commandName, newCommand.default || newCommand);
      
      logger.info(`Reloaded command: ${commandName}`);
      return true;
    } catch (error) {
      logger.error(`Error reloading command ${commandName}:`, error);
      return false;
    }
  }
}