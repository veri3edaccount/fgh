import { Client, GatewayIntentBits, Partials, Collection } from 'discord.js';
import { config } from 'dotenv';
import { connectDatabase } from './database/connection.js';
import { logger } from './utils/logger.js';
import { CommandManager } from './managers/CommandManager.js';
import { EventManager } from './managers/EventManager.js';
import { SecurityManager } from './security/SecurityManager.js';
import { EconomyManager } from './modules/economy/EconomyManager.js';
import { TicketManager } from './modules/tickets/TicketManager.js';
import { AutoModManager } from './modules/automod/AutoModManager.js';
import { AnalyticsManager } from './modules/analytics/AnalyticsManager.js';
import { AIManager } from './modules/ai/AIManager.js';
import { IntegrationManager } from './modules/integrations/IntegrationManager.js';

// Load environment variables
config();

export class UltimateBot extends Client {
  public commands = new Collection();
  public cooldowns = new Collection();
  public commandManager: CommandManager;
  public eventManager: EventManager;
  public securityManager: SecurityManager;
  public economyManager: EconomyManager;
  public ticketManager: TicketManager;
  public autoModManager: AutoModManager;
  public analyticsManager: AnalyticsManager;
  public aiManager: AIManager;
  public integrationManager: IntegrationManager;

  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.MessageContent,
      ],
      partials: [
        Partials.Channel,
        Partials.Message,
        Partials.User,
        Partials.GuildMember,
        Partials.Reaction,
      ],
    });

    this.initializeManagers();
  }

  private async initializeManagers() {
    this.commandManager = new CommandManager(this);
    this.eventManager = new EventManager(this);
    this.securityManager = new SecurityManager(this);
    this.economyManager = new EconomyManager(this);
    this.ticketManager = new TicketManager(this);
    this.autoModManager = new AutoModManager(this);
    this.analyticsManager = new AnalyticsManager(this);
    this.aiManager = new AIManager(this);
    this.integrationManager = new IntegrationManager(this);
  }

  public async start() {
    try {
      // Connect to database
      await connectDatabase();
      logger.info('Connected to database');

      // Load commands and events
      await this.commandManager.loadCommands();
      await this.eventManager.loadEvents();
      
      // Initialize all managers
      await this.securityManager.initialize();
      await this.economyManager.initialize();
      await this.ticketManager.initialize();
      await this.autoModManager.initialize();
      await this.analyticsManager.initialize();
      await this.aiManager.initialize();
      await this.integrationManager.initialize();

      // Login to Discord
      await this.login(process.env.DISCORD_TOKEN);
      logger.info('Ultimate Discord Bot is now online!');

    } catch (error) {
      logger.error('Failed to start bot:', error);
      process.exit(1);
    }
  }
}

// Create and start the bot
const bot = new UltimateBot();
bot.start();

// Graceful shutdown
process.on('SIGINT', () => {
  logger.info('Shutting down bot...');
  bot.destroy();
  process.exit(0);
});

export default bot;