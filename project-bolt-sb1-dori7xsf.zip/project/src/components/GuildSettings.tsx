import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Save, Shield, DollarSign, Ticket, Bot, BarChart3, Globe } from 'lucide-react';

interface GuildSettingsProps {
  user: any;
}

const GuildSettings: React.FC<GuildSettingsProps> = ({ user }) => {
  const { guildId } = useParams();
  const [guild, setGuild] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('moderation');

  useEffect(() => {
    fetchGuildSettings();
  }, [guildId]);

  const fetchGuildSettings = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/guilds/${guildId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const guildData = await response.json();
        setGuild(guildData);
      }
    } catch (error) {
      console.error('Error fetching guild settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/guilds/${guildId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(guild)
      });
      
      if (response.ok) {
        // Show success message
        alert('Settings saved successfully!');
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (path: string, value: any) => {
    setGuild((prev: any) => {
      const newGuild = { ...prev };
      const keys = path.split('.');
      let current = newGuild;
      
      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) current[keys[i]] = {};
        current = current[keys[i]];
      }
      
      current[keys[keys.length - 1]] = value;
      return newGuild;
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!guild) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-400">Guild not found or access denied.</p>
      </div>
    );
  }

  const tabs = [
    { id: 'moderation', name: 'Moderation', icon: Shield },
    { id: 'economy', name: 'Economy', icon: DollarSign },
    { id: 'tickets', name: 'Tickets', icon: Ticket },
    { id: 'ai', name: 'AI Features', icon: Bot },
    { id: 'analytics', name: 'Analytics', icon: BarChart3 },
    { id: 'integrations', name: 'Integrations', icon: Globe }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">{guild.name}</h1>
            <p className="text-gray-400">Configure your server settings</p>
          </div>
          <button
            onClick={saveSettings}
            disabled={saving}
            className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white rounded-lg transition-colors"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-gray-800 rounded-xl border border-gray-700">
        <div className="border-b border-gray-700">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-400'
                      : 'border-transparent text-gray-400 hover:text-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {/* Moderation Tab */}
          {activeTab === 'moderation' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Moderation Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white font-medium">Enable Moderation</label>
                      <p className="text-gray-400 text-sm">Enable automatic moderation features</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={guild.moderation?.enabled || false}
                      onChange={(e) => updateSetting('moderation.enabled', e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                    />
                  </div>

                  <div>
                    <label className="block text-white font-medium mb-2">Log Channel</label>
                    <input
                      type="text"
                      value={guild.moderation?.logChannel || ''}
                      onChange={(e) => updateSetting('moderation.logChannel', e.target.value)}
                      placeholder="Channel ID for moderation logs"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-white font-medium mb-2">Muted Role</label>
                    <input
                      type="text"
                      value={guild.moderation?.mutedRole || ''}
                      onChange={(e) => updateSetting('moderation.mutedRole', e.target.value)}
                      placeholder="Role ID for muted users"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                    />
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-md font-semibold text-white mb-4">AutoMod Settings</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <label className="text-white">Filter Profanity</label>
                    <input
                      type="checkbox"
                      checked={guild.moderation?.automod?.filterProfanity || false}
                      onChange={(e) => updateSetting('moderation.automod.filterProfanity', e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-white">Filter Spam</label>
                    <input
                      type="checkbox"
                      checked={guild.moderation?.automod?.filterSpam || false}
                      onChange={(e) => updateSetting('moderation.automod.filterSpam', e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-white">Filter Invites</label>
                    <input
                      type="checkbox"
                      checked={guild.moderation?.automod?.filterInvites || false}
                      onChange={(e) => updateSetting('moderation.automod.filterInvites', e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-white">AI Moderation</label>
                    <input
                      type="checkbox"
                      checked={guild.moderation?.automod?.aiModeration || false}
                      onChange={(e) => updateSetting('moderation.automod.aiModeration', e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Economy Tab */}
          {activeTab === 'economy' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Economy Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white font-medium">Enable Economy</label>
                      <p className="text-gray-400 text-sm">Enable currency and economy features</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={guild.economy?.enabled || false}
                      onChange={(e) => updateSetting('economy.enabled', e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                    />
                  </div>

                  <div>
                    <label className="block text-white font-medium mb-2">Currency Symbol</label>
                    <input
                      type="text"
                      value={guild.economy?.currency || '💰'}
                      onChange={(e) => updateSetting('economy.currency', e.target.value)}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-white font-medium mb-2">Daily Amount</label>
                      <input
                        type="number"
                        value={guild.economy?.dailyAmount || 1000}
                        onChange={(e) => updateSetting('economy.dailyAmount', parseInt(e.target.value))}
                        className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-white font-medium mb-2">Work Amount</label>
                      <input
                        type="number"
                        value={guild.economy?.workAmount || 500}
                        onChange={(e) => updateSetting('economy.workAmount', parseInt(e.target.value))}
                        className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-white font-medium mb-2">Starting Balance</label>
                      <input
                        type="number"
                        value={guild.economy?.startingBalance || 1000}
                        onChange={(e) => updateSetting('economy.startingBalance', parseInt(e.target.value))}
                        className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Add other tabs content here */}
          {activeTab === 'tickets' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Ticket System</h3>
                <p className="text-gray-400 mb-4">Configure the support ticket system for your server.</p>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white font-medium">Enable Tickets</label>
                      <p className="text-gray-400 text-sm">Allow users to create support tickets</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={guild.tickets?.enabled || false}
                      onChange={(e) => updateSetting('tickets.enabled', e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                    />
                  </div>

                  <div>
                    <label className="block text-white font-medium mb-2">Ticket Category</label>
                    <input
                      type="text"
                      value={guild.tickets?.category || ''}
                      onChange={(e) => updateSetting('tickets.category', e.target.value)}
                      placeholder="Category ID for ticket channels"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-white font-medium mb-2">Support Role</label>
                    <input
                      type="text"
                      value={guild.tickets?.supportRole || ''}
                      onChange={(e) => updateSetting('tickets.supportRole', e.target.value)}
                      placeholder="Role ID for support staff"
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Analytics Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="text-white font-medium">Enable Analytics</label>
                      <p className="text-gray-400 text-sm">Track server activity and generate insights</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={guild.analytics?.enabled || false}
                      onChange={(e) => updateSetting('analytics.enabled', e.target.checked)}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center justify-between">
                      <label className="text-white">Track Messages</label>
                      <input
                        type="checkbox"
                        checked={guild.analytics?.trackMessages || false}
                        onChange={(e) => updateSetting('analytics.trackMessages', e.target.checked)}
                        className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <label className="text-white">Track Voice</label>
                      <input
                        type="checkbox"
                        checked={guild.analytics?.trackVoice || false}
                        onChange={(e) => updateSetting('analytics.trackVoice', e.target.checked)}
                        className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <label className="text-white">Track Commands</label>
                      <input
                        type="checkbox"
                        checked={guild.analytics?.trackCommands || false}
                        onChange={(e) => updateSetting('analytics.trackCommands', e.target.checked)}
                        className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GuildSettings;