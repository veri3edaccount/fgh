import React, { useState, useEffect } from 'react';
import { Users, MessageSquare, Zap, Shield, TrendingUp, Activity } from 'lucide-react';

interface DashboardProps {
  user: {
    userId: string;
    username: string;
    guilds: Array<{
      id: string;
      name: string;
      icon: string;
    }>;
  };
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [guilds, setGuilds] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalServers: 0,
    totalMembers: 0,
    totalCommands: 0,
    activeToday: 0
  });

  useEffect(() => {
    fetchGuilds();
  }, []);

  const fetchGuilds = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/guilds', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const guildsData = await response.json();
        setGuilds(guildsData);
        
        // Calculate stats
        setStats({
          totalServers: guildsData.length,
          totalMembers: guildsData.reduce((sum: number, guild: any) => sum + (guild.approximate_member_count || 0), 0),
          totalCommands: 0, // This would come from analytics
          activeToday: guildsData.filter((g: any) => g.settings?.analytics?.enabled).length
        });
      }
    } catch (error) {
      console.error('Error fetching guilds:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome back, {user.username}!</h1>
        <p className="text-blue-100">Here's what's happening with your Discord servers today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Total Servers</p>
              <p className="text-2xl font-bold text-white">{stats.totalServers}</p>
            </div>
            <Users className="h-8 w-8 text-blue-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Total Members</p>
              <p className="text-2xl font-bold text-white">{stats.totalMembers.toLocaleString()}</p>
            </div>
            <MessageSquare className="h-8 w-8 text-green-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Commands Today</p>
              <p className="text-2xl font-bold text-white">{stats.totalCommands.toLocaleString()}</p>
            </div>
            <Zap className="h-8 w-8 text-yellow-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Active Servers</p>
              <p className="text-2xl font-bold text-white">{stats.activeToday}</p>
            </div>
            <Activity className="h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h2 className="text-xl font-semibold text-white mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center p-4 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
            <Shield className="h-6 w-6 mr-3" />
            <span>Security Scan</span>
          </button>
          <button className="flex items-center p-4 bg-green-600 hover:bg-green-700 rounded-lg transition-colors">
            <TrendingUp className="h-6 w-6 mr-3" />
            <span>View Analytics</span>
          </button>
          <button className="flex items-center p-4 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors">
            <Zap className="h-6 w-6 mr-3" />
            <span>Manage Commands</span>
          </button>
        </div>
      </div>

      {/* Server List */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h2 className="text-xl font-semibold text-white mb-4">Your Servers</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {guilds.map((guild) => (
            <div key={guild.id} className="bg-gray-700 rounded-lg p-4 hover:bg-gray-600 transition-colors cursor-pointer">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center mr-3">
                  {guild.icon ? (
                    <img
                      src={`https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`}
                      alt={guild.name}
                      className="w-12 h-12 rounded-full"
                    />
                  ) : (
                    <span className="text-lg font-semibold text-gray-300">
                      {guild.name.charAt(0)}
                    </span>
                  )}
                </div>
                <div>
                  <h3 className="font-semibold text-white">{guild.name}</h3>
                  <p className="text-sm text-gray-400">
                    {guild.settings ? 'Configured' : 'Not configured'}
                  </p>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className={`px-2 py-1 rounded text-xs ${
                  guild.settings?.analytics?.enabled 
                    ? 'bg-green-600 text-green-100' 
                    : 'bg-gray-600 text-gray-300'
                }`}>
                  {guild.settings?.analytics?.enabled ? 'Active' : 'Inactive'}
                </span>
                <button 
                  onClick={() => window.location.href = `/guild/${guild.id}`}
                  className="text-blue-400 hover:text-blue-300 text-sm"
                >
                  Configure →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h2 className="text-xl font-semibold text-white mb-4">Recent Activity</h2>
        <div className="space-y-3">
          <div className="flex items-center p-3 bg-gray-700 rounded-lg">
            <div className="w-2 h-2 bg-green-400 rounded-full mr-3"></div>
            <span className="text-gray-300">Bot connected to {guilds.length} servers</span>
            <span className="text-gray-500 text-sm ml-auto">Just now</span>
          </div>
          <div className="flex items-center p-3 bg-gray-700 rounded-lg">
            <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
            <span className="text-gray-300">Security scan completed</span>
            <span className="text-gray-500 text-sm ml-auto">5 minutes ago</span>
          </div>
          <div className="flex items-center p-3 bg-gray-700 rounded-lg">
            <div className="w-2 h-2 bg-yellow-400 rounded-full mr-3"></div>
            <span className="text-gray-300">Analytics data updated</span>
            <span className="text-gray-500 text-sm ml-auto">10 minutes ago</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;