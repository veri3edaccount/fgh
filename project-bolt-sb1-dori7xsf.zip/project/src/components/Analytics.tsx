import React, { useState, useEffect } from 'react';
import { BarChart3, Users, MessageSquare, Zap, TrendingUp, Activity } from 'lucide-react';

interface AnalyticsProps {
  user: any;
}

const Analytics: React.FC<AnalyticsProps> = ({ user }) => {
  const [selectedGuild, setSelectedGuild] = useState<string>('');
  const [analytics, setAnalytics] = useState<any>(null);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user.guilds.length > 0 && !selectedGuild) {
      setSelectedGuild(user.guilds[0].id);
    }
  }, [user.guilds, selectedGuild]);

  useEffect(() => {
    if (selectedGuild) {
      fetchAnalytics();
      fetchLeaderboard();
    }
  }, [selectedGuild]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/analytics/guild/${selectedGuild}?days=7`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setAnalytics(data);
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchLeaderboard = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/analytics/leaderboard/${selectedGuild}?type=experience&limit=10`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setLeaderboard(data);
      }
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
    }
  };

  const selectedGuildData = user.guilds.find((g: any) => g.id === selectedGuild);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Analytics Dashboard</h1>
            <p className="text-gray-400">Detailed insights into your server activity</p>
          </div>
          <div>
            <select
              value={selectedGuild}
              onChange={(e) => setSelectedGuild(e.target.value)}
              className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
            >
              {user.guilds.map((guild: any) => (
                <option key={guild.id} value={guild.id}>
                  {guild.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <>
          {/* Stats Overview */}
          {analytics && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Total Messages</p>
                    <p className="text-2xl font-bold text-white">{analytics.messages.toLocaleString()}</p>
                    <p className="text-green-400 text-sm">Last 7 days</p>
                  </div>
                  <MessageSquare className="h-8 w-8 text-blue-400" />
                </div>
              </div>

              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Commands Used</p>
                    <p className="text-2xl font-bold text-white">{analytics.commands.toLocaleString()}</p>
                    <p className="text-green-400 text-sm">Last 7 days</p>
                  </div>
                  <Zap className="h-8 w-8 text-yellow-400" />
                </div>
              </div>

              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Active Users</p>
                    <p className="text-2xl font-bold text-white">{analytics.activeUsers}</p>
                    <p className="text-green-400 text-sm">This week</p>
                  </div>
                  <Users className="h-8 w-8 text-green-400" />
                </div>
              </div>

              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Growth Rate</p>
                    <p className="text-2xl font-bold text-white">+12.5%</p>
                    <p className="text-green-400 text-sm">vs last week</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-400" />
                </div>
              </div>
            </div>
          )}

          {/* Activity Chart */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h2 className="text-xl font-semibold text-white mb-4">Daily Activity</h2>
            {analytics?.dailyStats && (
              <div className="space-y-4">
                {analytics.dailyStats.map((day: any, index: number) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-gray-300 w-24">{new Date(day.date).toLocaleDateString()}</span>
                    <div className="flex-1 mx-4">
                      <div className="bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-blue-500 h-2 rounded-full"
                          style={{
                            width: `${Math.min((day.messages / Math.max(...analytics.dailyStats.map((d: any) => d.messages))) * 100, 100)}%`
                          }}
                        ></div>
                      </div>
                    </div>
                    <span className="text-gray-300 w-16 text-right">{day.messages}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Leaderboard */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-semibold text-white mb-4">Top Users by Experience</h2>
              <div className="space-y-3">
                {leaderboard.map((user, index) => (
                  <div key={user._id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                    <div className="flex items-center">
                      <span className="text-gray-400 w-8">#{index + 1}</span>
                      <div className="ml-3">
                        <p className="text-white font-medium">{user.username}</p>
                        <p className="text-gray-400 text-sm">Level {user.experience?.level || 1}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">{(user.experience?.total || 0).toLocaleString()} XP</p>
                      <p className="text-gray-400 text-sm">{(user.experience?.messageCount || 0).toLocaleString()} messages</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-semibold text-white mb-4">Server Insights</h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center">
                    <Activity className="h-5 w-5 text-green-400 mr-3" />
                    <span className="text-white">Peak Activity</span>
                  </div>
                  <span className="text-gray-300">2:00 PM - 6:00 PM</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center">
                    <MessageSquare className="h-5 w-5 text-blue-400 mr-3" />
                    <span className="text-white">Most Active Channel</span>
                  </div>
                  <span className="text-gray-300">#general</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center">
                    <Zap className="h-5 w-5 text-yellow-400 mr-3" />
                    <span className="text-white">Most Used Command</span>
                  </div>
                  <span className="text-gray-300">/balance</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div className="flex items-center">
                    <Users className="h-5 w-5 text-purple-400 mr-3" />
                    <span className="text-white">Member Retention</span>
                  </div>
                  <span className="text-green-400">94.2%</span>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Analytics;