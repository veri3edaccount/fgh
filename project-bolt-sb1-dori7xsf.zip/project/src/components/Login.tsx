import React from 'react';
import { Shield, Bot, Zap, Users, BarChart3, Lock, Globe, Cpu } from 'lucide-react';

const Login: React.FC = () => {
  const handleLogin = () => {
    window.location.href = '/api/auth/discord';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex justify-center mb-8">
              <div className="relative">
                <Bot className="h-24 w-24 text-blue-400 animate-pulse" />
                <div className="absolute -top-2 -right-2 h-6 w-6 bg-green-500 rounded-full animate-ping"></div>
              </div>
            </div>
            
            <h1 className="text-6xl font-bold text-white mb-6">
              Ultimate Discord Bot
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              The most advanced Discord bot system with AI-powered moderation, comprehensive analytics, 
              economy features, and enterprise-grade security. Built for servers that demand excellence.
            </p>
            
            <button
              onClick={handleLogin}
              className="inline-flex items-center px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              <Shield className="h-6 w-6 mr-3" />
              Login with Discord
            </button>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Powerful Features</h2>
          <p className="text-xl text-gray-300">Everything you need to manage and grow your Discord community</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Security & Moderation */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700 hover:border-blue-500 transition-all duration-300">
            <div className="flex items-center mb-6">
              <Shield className="h-8 w-8 text-red-400 mr-3" />
              <h3 className="text-xl font-semibold text-white">Advanced Security</h3>
            </div>
            <ul className="space-y-3 text-gray-300">
              <li>• AI-powered automoderation</li>
              <li>• Anti-raid protection</li>
              <li>• Smart spam detection</li>
              <li>• Alt account detection</li>
              <li>• Custom filter rules</li>
            </ul>
          </div>

          {/* Analytics */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700 hover:border-green-500 transition-all duration-300">
            <div className="flex items-center mb-6">
              <BarChart3 className="h-8 w-8 text-green-400 mr-3" />
              <h3 className="text-xl font-semibold text-white">Deep Analytics</h3>
            </div>
            <ul className="space-y-3 text-gray-300">
              <li>• Real-time server insights</li>
              <li>• User activity tracking</li>
              <li>• Command usage statistics</li>
              <li>• Growth metrics</li>
              <li>• Custom reports</li>
            </ul>
          </div>

          {/* Economy */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700 hover:border-yellow-500 transition-all duration-300">
            <div className="flex items-center mb-6">
              <Zap className="h-8 w-8 text-yellow-400 mr-3" />
              <h3 className="text-xl font-semibold text-white">Economy System</h3>
            </div>
            <ul className="space-y-3 text-gray-300">
              <li>• Virtual currency & banking</li>
              <li>• Mini-games & gambling</li>
              <li>• Shop & marketplace</li>
              <li>• Daily rewards & streaks</li>
              <li>• Investment system</li>
            </ul>
          </div>

          {/* AI Features */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700 hover:border-purple-500 transition-all duration-300">
            <div className="flex items-center mb-6">
              <Cpu className="h-8 w-8 text-purple-400 mr-3" />
              <h3 className="text-xl font-semibold text-white">AI Integration</h3>
            </div>
            <ul className="space-y-3 text-gray-300">
              <li>• GPT-powered responses</li>
              <li>• Smart conversation AI</li>
              <li>• Auto-translation</li>
              <li>• Content summarization</li>
              <li>• Personalized interactions</li>
            </ul>
          </div>

          {/* Community */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700 hover:border-blue-500 transition-all duration-300">
            <div className="flex items-center mb-6">
              <Users className="h-8 w-8 text-blue-400 mr-3" />
              <h3 className="text-xl font-semibold text-white">Community Tools</h3>
            </div>
            <ul className="space-y-3 text-gray-300">
              <li>• Advanced ticket system</li>
              <li>• Reaction roles</li>
              <li>• Custom commands</li>
              <li>• Giveaway management</li>
              <li>• Welcome automation</li>
            </ul>
          </div>

          {/* Integrations */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700 hover:border-indigo-500 transition-all duration-300">
            <div className="flex items-center mb-6">
              <Globe className="h-8 w-8 text-indigo-400 mr-3" />
              <h3 className="text-xl font-semibold text-white">Integrations</h3>
            </div>
            <ul className="space-y-3 text-gray-300">
              <li>• Twitch & YouTube alerts</li>
              <li>• Social media monitoring</li>
              <li>• Webhook support</li>
              <li>• API connectivity</li>
              <li>• Third-party services</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gray-800/30 backdrop-blur-sm py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-400 mb-2">99.9%</div>
              <div className="text-gray-300">Uptime</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-400 mb-2">1M+</div>
              <div className="text-gray-300">Commands Processed</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">500+</div>
              <div className="text-gray-300">Servers Protected</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-purple-400 mb-2">24/7</div>
              <div className="text-gray-300">Support</div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h2 className="text-4xl font-bold text-white mb-6">Ready to Transform Your Server?</h2>
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Join thousands of Discord communities that trust Ultimate Bot for their moderation, 
          engagement, and growth needs.
        </p>
        <button
          onClick={handleLogin}
          className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
        >
          <Lock className="h-6 w-6 mr-3" />
          Get Started Now
        </button>
      </div>
    </div>
  );
};

export default Login;